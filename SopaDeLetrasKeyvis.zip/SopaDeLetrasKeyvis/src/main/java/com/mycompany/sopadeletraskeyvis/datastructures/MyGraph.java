/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sopadeletraskeyvis.datastructures;

/**
 * Una implementación básica de un grafo no dirigido utilizando una matriz de adyacencia.
 * Representa las conexiones entre los "vértices" (letras del tablero).
 */
public class MyGraph {
    private boolean[][] adjMatrix; // Matriz de adyacencia: adjMatrix[i][j] es true si hay una arista entre i y j
    private int numVertices;       // Número total de vértices en el grafo

    /**
     * Constructor que inicializa el grafo con un número específico de vértices.
     * @param numVertices El número de vértices en el grafo.
     */
    public MyGraph(int numVertices) {
        this.numVertices = numVertices;
        this.adjMatrix = new boolean[numVertices][numVertices];
        // Por defecto, todos los valores en boolean[][] son false, lo que indica que no hay aristas.
    }

    /**
     * Agrega una arista entre dos vértices. Dado que es un grafo no dirigido,
     * la arista se añade en ambas direcciones.
     * @param v1 El primer vértice.
     * @param v2 El segundo vértice.
     */
    public void addEdge(int v1, int v2) {
        if (v1 >= 0 && v1 < numVertices && v2 >= 0 && v2 < numVertices) {
            adjMatrix[v1][v2] = true;
            adjMatrix[v2][v1] = true; // Para grafo no dirigido
        } else {
            System.err.println("Error: Vértices fuera de rango en addEdge (" + v1 + ", " + v2 + ")");
        }
    }

    /**
     * Elimina una arista entre dos vértices.
     * @param v1 El primer vértice.
     * @param v2 El segundo vértice.
     */
    public void removeEdge(int v1, int v2) {
        if (v1 >= 0 && v1 < numVertices && v2 >= 0 && v2 < numVertices) {
            adjMatrix[v1][v2] = false;
            adjMatrix[v2][v1] = false; // Para grafo no dirigido
        } else {
            System.err.println("Error: Vértices fuera de rango en removeEdge (" + v1 + ", " + v2 + ")");
        }
    }

    /**
     * Verifica si existe una arista entre dos vértices.
     * @param v1 El primer vértice.
     * @param v2 El segundo vértice.
     * @return true si existe una arista entre v1 y v2, false en caso contrario.
     */
    public boolean hasEdge(int v1, int v2) {
        if (v1 >= 0 && v1 < numVertices && v2 >= 0 && v2 < numVertices) {
            return adjMatrix[v1][v2];
        }
        return false;
    }

    /**
     * Devuelve el número total de vértices en el grafo.
     * @return El número de vértices.
     */
    public int getNumVertices() {
        return numVertices;
    }

    /**
     * Obtiene una lista de los vecinos adyacentes a un vértice dado.
     * @param v El vértice del cual se quieren obtener los vecinos.
     * @return Un objeto MyList que contiene los índices de los vértices adyacentes.
     */
    public MyList getNeighbors(int v) {
        MyList neighbors = new MyList();
        if (v >= 0 && v < numVertices) {
            for (int i = 0; i < numVertices; i++) {
                if (adjMatrix[v][i]) {
                    neighbors.add(i);
                }
            }
        } else {
            System.err.println("Error: Vértice fuera de rango en getNeighbors (" + v + ")");
        }
        return neighbors;
    }
}
