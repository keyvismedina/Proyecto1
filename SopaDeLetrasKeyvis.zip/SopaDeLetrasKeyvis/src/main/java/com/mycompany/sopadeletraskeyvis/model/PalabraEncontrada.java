/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sopadeletraskeyvis.model;

/**
 * Representa una palabra que ha sido encontrada en el tablero de la sopa de letras.
 * Incluye la palabra en sí y la ruta de coordenadas (fila, columna) por la que fue formada.
 */
public class PalabraEncontrada {
    private String palabra;
    // La ruta será un arreglo de arreglos de enteros, donde cada int[] es {fila, columna}
    private int[][] ruta; 

    /**
     * Constructor de PalabraEncontrada.
     * @param palabra La palabra que fue encontrada.
     * @param ruta Un arreglo bidimensional de enteros que representa la secuencia de coordenadas
     * (fila, columna) que forman la palabra en el tablero.
     */
    public PalabraEncontrada(String palabra, int[][] ruta) {
        if (palabra == null || palabra.isEmpty()) {
            throw new IllegalArgumentException("La palabra no puede ser nula o vacía.");
        }
        if (ruta == null || ruta.length == 0) {
            throw new IllegalArgumentException("La ruta no puede ser nula o vacía.");
        }
        this.palabra = palabra;
        // Se hace una copia defensiva de la ruta para evitar modificaciones externas inesperadas
        this.ruta = new int[ruta.length][2];
        for (int i = 0; i < ruta.length; i++) {
            this.ruta[i][0] = ruta[i][0];
            this.ruta[i][1] = ruta[i][1];
        }
    }

    /**
     * Obtiene la palabra encontrada.
     * @return La palabra como un String.
     */
    public String getPalabra() {
        return palabra;
    }

    /**
     * Obtiene la ruta de coordenadas de la palabra encontrada.
     * @return Un arreglo bidimensional de enteros, donde cada int[] es {fila, columna}.
     */
    public int[][] getRuta() {
        // Devolvemos una copia defensiva para proteger la inmutabilidad de la ruta interna
        int[][] rutaCopia = new int[ruta.length][2];
        for (int i = 0; i < ruta.length; i++) {
            rutaCopia[i][0] = ruta[i][0];
            rutaCopia[i][1] = ruta[i][1];
        }
        return rutaCopia;
    }
    
    /**
     * Representación en String de la PalabraEncontrada.
     * @return Un String que describe la palabra y su ruta.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Palabra: ").append(palabra).append(", Ruta: [");
        for (int i = 0; i < ruta.length; i++) {
            sb.append("(").append(ruta[i][0]).append(",").append(ruta[i][1]).append(")");
            if (i < ruta.length - 1) {
                sb.append(" -> ");
            }
        }
        sb.append("]");
        return sb.toString();
    }
}
