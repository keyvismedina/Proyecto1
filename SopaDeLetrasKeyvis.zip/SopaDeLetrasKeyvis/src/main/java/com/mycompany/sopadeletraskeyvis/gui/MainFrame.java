/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sopadeletraskeyvis.gui;

import com.mycompany.sopadeletraskeyvis.model.Tablero;
import com.mycompany.sopadeletraskeyvis.model.Diccionario;
import com.mycompany.sopadeletraskeyvis.model.BuscadorSopaLetras;
import com.mycompany.sopadeletraskeyvis.model.PalabraEncontrada;
import com.mycompany.sopadeletraskeyvis.utils.FileReader;
import com.mycompany.sopadeletraskeyvis.utils.Timer;
import com.mycompany.sopadeletraskeyvis.datastructures.MyList;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

// GraphStream imports (as mentioned, can be used for graphical representation of the graph)
// import org.graphstream.graph.*;
// import org.graphstream.graph.implementations.*;
// import org.graphstream.ui.view.Viewer;

/**
 * Clase principal de la interfaz gráfica de usuario para la Sopa de Letras Keyvis.
 * Permite cargar archivos, visualizar el tablero y el diccionario,
 * buscar palabras usando DFS/BFS y mostrar los resultados.
 */
public class MainFrame extends JFrame {

    private Tablero tablero;
    private Diccionario diccionario;
    private BuscadorSopaLetras buscador;

    // Componentes de la GUI
    private JTextArea tableroTextArea;
    private JTextArea diccionarioTextArea;
    // La variable resultadosTextArea ya no es necesaria si usas JTable, la comento para claridad.
    // private JTextArea resultadosTextArea; 
    private JLabel tiempoEjecucionLabel;
    private JTextField buscarPalabraField;

    // Tabla para mostrar resultados (más profesional que JTextArea para esto)
    private JTable resultadosTable;
    private DefaultTableModel resultadosTableModel;

    // DECLARACIONES DE JScrollPanes como miembros de la clase
    private JScrollPane tableroScrollPane;
    private JScrollPane diccionarioScrollPane;
    private JScrollPane resultadosScrollPane;
    // -------------------------------------------------------------------

    public MainFrame() {
        setTitle("Sopa de Letras Keyvis");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar la ventana

        initComponents();
        setupLayout();
        addListeners();
    }

    private void initComponents() {
        // Área para mostrar el tablero
        tableroTextArea = new JTextArea(5, 20);
        tableroTextArea.setEditable(false);
        tableroTextArea.setFont(new Font("Monospaced", Font.BOLD, 20));
        tableroTextArea.setBorder(BorderFactory.createTitledBorder("Tablero (4x4)"));
        // INICIALIZACIÓN: Ahora solo asignas a la variable miembro, no la declaras con 'JScrollPane'
        tableroScrollPane = new JScrollPane(tableroTextArea);

        // Área para mostrar el diccionario
        diccionarioTextArea = new JTextArea(10, 20);
        diccionarioTextArea.setEditable(false);
        diccionarioTextArea.setBorder(BorderFactory.createTitledBorder("Diccionario"));
        // INICIALIZACIÓN: Ahora solo asignas
        diccionarioScrollPane = new JScrollPane(diccionarioTextArea);

        // Campo para buscar palabra específica
        buscarPalabraField = new JTextField(20);
        buscarPalabraField.setBorder(BorderFactory.createTitledBorder("Buscar palabra específica"));

        // Tabla para resultados de búsqueda
        String[] columnNames = {"Palabra", "Ruta", "Método"};
        resultadosTableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Hacer que las celdas no sean editables
            }
        };
        resultadosTable = new JTable(resultadosTableModel);
        resultadosTable.setFont(new Font("Monospaced", Font.PLAIN, 12));
        resultadosTable.setRowHeight(20);
        // INICIALIZACIÓN: Ahora solo asignas
        resultadosScrollPane = new JScrollPane(resultadosTable);
        resultadosScrollPane.setBorder(BorderFactory.createTitledBorder("Resultados de Búsqueda"));
        
        tiempoEjecucionLabel = new JLabel("Tiempo de Ejecución: N/A");
        tiempoEjecucionLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
    }

    private void setupLayout() {
        setLayout(new BorderLayout(10, 10)); // Margen entre componentes

        // Panel superior para cargar archivo
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton cargarArchivoButton = new JButton("Cargar Archivo");
        topPanel.add(cargarArchivoButton);
        add(topPanel, BorderLayout.NORTH);

        // Panel central con tablero, diccionario y resultados
        JSplitPane centerSplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        centerSplitPane.setResizeWeight(0.3); // Tablero y diccionario ocupan 30% del ancho
        
        JPanel leftPanel = new JPanel(new GridLayout(2, 1, 10, 10));
        leftPanel.add(tableroScrollPane); // Accesible porque es miembro de la clase
        leftPanel.add(diccionarioScrollPane); // Accesible
        
        JSplitPane rightSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        rightSplitPane.setResizeWeight(0.7); // Resultados ocupan 70% del alto
        rightSplitPane.setTopComponent(resultadosScrollPane); // Accesible
        
        // Panel de controles de búsqueda y visualización
        JPanel searchControlsPanel = new JPanel();
        searchControlsPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); // Padding

        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.HORIZONTAL;
        searchControlsPanel.add(buscarPalabraField, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1; gbc.fill = GridBagConstraints.NONE;
        JButton buscarDFSButton = new JButton("Buscar Palabra (DFS)");
        searchControlsPanel.add(buscarDFSButton, gbc);

        gbc.gridx = 1; gbc.gridy = 1;
        JButton buscarBFSButton = new JButton("Buscar Palabra (BFS)");
        searchControlsPanel.add(buscarBFSButton, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 1;
        JButton buscarTodasDFSButton = new JButton("Todas las Palabras (DFS)");
        searchControlsPanel.add(buscarTodasDFSButton, gbc);

        gbc.gridx = 1; gbc.gridy = 2;
        JButton buscarTodasBFSButton = new JButton("Todas las Palabras (BFS)");
        searchControlsPanel.add(buscarTodasBFSButton, gbc);

        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.HORIZONTAL;
        JButton guardarDiccionarioButton = new JButton("Guardar Diccionario");
        searchControlsPanel.add(guardarDiccionarioButton, gbc);

        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.HORIZONTAL;
        searchControlsPanel.add(tiempoEjecucionLabel, gbc);
        
        rightSplitPane.setBottomComponent(searchControlsPanel);

        centerSplitPane.setLeftComponent(leftPanel);
        centerSplitPane.setRightComponent(rightSplitPane);
        
        add(centerSplitPane, BorderLayout.CENTER);
    }

    private void addListeners() {
        // Listener para el botón "Cargar Archivo"
        ((JButton)((JPanel)getContentPane().getComponent(0)).getComponent(0)).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setCurrentDirectory(new File(".")); // Iniciar en el directorio actual
                int result = fileChooser.showOpenDialog(MainFrame.this);
                if (result == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();
                    try {
                        Object[] data = FileReader.cargarDatos(selectedFile);
                        tablero = (Tablero) data[0];
                        diccionario = (Diccionario) data[1];
                        buscador = new BuscadorSopaLetras(tablero, diccionario);
                        displayTablero();
                        displayDiccionario();
                        clearResults();
                        JOptionPane.showMessageDialog(MainFrame.this, "Archivo cargado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    } catch (IOException | IllegalArgumentException ex) {
                        JOptionPane.showMessageDialog(MainFrame.this, "Error al cargar archivo: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                        tablero = null; // Limpiar datos si hay error
                        diccionario = null;
                        buscador = null;
                        tableroTextArea.setText("");
                        diccionarioTextArea.setText("");
                        clearResults();
                    }
                }
            }
        });

        // Listener para el botón "Buscar Palabra (DFS)" - CON MEJORA PARA AÑADIR AL DICCIONARIO
        getSearchButton("Buscar Palabra (DFS)").addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!checkDataLoaded()) return;
                clearResults();
                String targetWord = buscarPalabraField.getText().trim().toUpperCase(); // Normalizar la entrada
                if (targetWord.isEmpty()) { 
                    JOptionPane.showMessageDialog(MainFrame.this, "Por favor, ingrese la palabra a buscar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                Timer timer = new Timer();
                timer.start();
                PalabraEncontrada found = buscador.buscarPalabraDFS(targetWord);
                timer.stop();
                tiempoEjecucionLabel.setText("Tiempo de Ejecución (DFS - una palabra): " + timer.getElapsedTimeMillis() + " ms");
                
                if (found != null) {
                    resultadosTableModel.addRow(new Object[]{found.getPalabra(), formatPath(found.getRuta()), "DFS (Una)"});
                    // *** LÓGICA: Añadir al diccionario si se encuentra y no estaba presente ***
                    if (!diccionario.existePalabra(found.getPalabra())) {
                        diccionario.agregarPalabra(found.getPalabra());
                        displayDiccionario(); // Actualizar la visualización del diccionario
                        JOptionPane.showMessageDialog(MainFrame.this, "Palabra '" + found.getPalabra() + "' encontrada y agregada al diccionario.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(MainFrame.this, "Palabra '" + found.getPalabra() + "' encontrada (ya estaba en el diccionario).", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(MainFrame.this, "La palabra '" + targetWord + "' no se encontró con DFS.", "Resultado", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        // Listener para el botón "Buscar Palabra (BFS)" - CON MEJORA PARA AÑADIR AL DICCIONARIO
        getSearchButton("Buscar Palabra (BFS)").addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!checkDataLoaded()) return;
                clearResults();
                String targetWord = buscarPalabraField.getText().trim().toUpperCase(); // Normalizar la entrada
                 if (targetWord.isEmpty()) { 
                    JOptionPane.showMessageDialog(MainFrame.this, "Por favor, ingrese la palabra a buscar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                Timer timer = new Timer();
                timer.start();
                PalabraEncontrada found = buscador.buscarPalabraBFS(targetWord);
                timer.stop();
                tiempoEjecucionLabel.setText("Tiempo de Ejecución (BFS - una palabra): " + timer.getElapsedTimeMillis() + " ms");
                
                if (found != null) {
                    resultadosTableModel.addRow(new Object[]{found.getPalabra(), formatPath(found.getRuta()), "BFS (Una)"});
                    // *** LÓGICA: Añadir al diccionario si se encuentra y no estaba presente ***
                    if (!diccionario.existePalabra(found.getPalabra())) {
                        diccionario.agregarPalabra(found.getPalabra());
                        displayDiccionario(); // Actualizar la visualización del diccionario
                        JOptionPane.showMessageDialog(MainFrame.this, "Palabra '" + found.getPalabra() + "' encontrada y agregada al diccionario.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(MainFrame.this, "Palabra '" + found.getPalabra() + "' encontrada (ya estaba en el diccionario).", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(MainFrame.this, "La palabra '" + targetWord + "' no se encontró con BFS.", "Resultado", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
        
        // Listener para el botón "Todas las Palabras (DFS)"
        getSearchButton("Todas las Palabras (DFS)").addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!checkDataLoaded()) return;
                clearResults();
                Timer timer = new Timer();
                timer.start();
                MyList foundWords = buscador.buscarTodasLasPalabrasDFS();
                timer.stop();
                tiempoEjecucionLabel.setText("Tiempo de Ejecución (DFS - todas): " + timer.getElapsedTimeMillis() + " ms");
                displayFoundWords(foundWords, "DFS (Todas)");
            }
        });

        // Listener para el botón "Todas las Palabras (BFS)"
        getSearchButton("Todas las Palabras (BFS)").addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!checkDataLoaded()) return;
                clearResults();
                Timer timer = new Timer();
                timer.start();
                MyList foundWords = buscador.buscarTodasLasPalabrasBFS();
                timer.stop();
                tiempoEjecucionLabel.setText("Tiempo de Ejecución (BFS - todas): " + timer.getElapsedTimeMillis() + " ms");
                displayFoundWords(foundWords, "BFS (Todas)");
            }
        });

        // Listener para el botón "Guardar Diccionario"
        getSearchButton("Guardar Diccionario").addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (diccionario == null) {
                    JOptionPane.showMessageDialog(MainFrame.this, "No hay diccionario cargado para guardar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setCurrentDirectory(new File("."));
                fileChooser.setDialogTitle("Guardar Diccionario como...");
                int userSelection = fileChooser.showSaveDialog(MainFrame.this);

                if (userSelection == JFileChooser.APPROVE_OPTION) {
                    File fileToSave = fileChooser.getSelectedFile();
                    try {
                        FileReader.guardarDiccionario(fileToSave, diccionario);
                        JOptionPane.showMessageDialog(MainFrame.this, "Diccionario guardado exitosamente en: " + fileToSave.getAbsolutePath(), "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    } catch (IOException ex) {
                        JOptionPane.showMessageDialog(MainFrame.this, "Error al guardar el diccionario: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
    }

    /**
     * Muestra el tablero en el JTextArea correspondiente.
     */
    private void displayTablero() {
        if (tablero == null) {
            tableroTextArea.setText("No hay tablero cargado.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < tablero.getFilas(); i++) {
            for (int j = 0; j < tablero.getColumnas(); j++) {
                sb.append(tablero.getLetra(i, j)).append("  ");
            }
            sb.append("\n");
        }
        tableroTextArea.setText(sb.toString());
    }

    /**
     * Muestra el diccionario en el JTextArea correspondiente.
     */
    private void displayDiccionario() {
        if (diccionario == null) {
            diccionarioTextArea.setText("No hay diccionario cargado.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        String[] palabras = diccionario.getTodasLasPalabras();
        if (palabras.length == 0) {
            sb.append("Diccionario vacío.");
        } else {
            // Recorrer las palabras y añadirlas
            for (String palabra : palabras) {
                sb.append("- ").append(palabra).append("\n");
            }
        }
        diccionarioTextArea.setText(sb.toString());
        // Ajustar el scroll para que las nuevas palabras sean visibles (opcional)
        diccionarioTextArea.setCaretPosition(diccionarioTextArea.getDocument().getLength());
    }

    /**
     * Muestra las palabras encontradas en la tabla de resultados.
     * @param foundWords La MyList de objetos PalabraEncontrada.
     * @param method El método de búsqueda utilizado (DFS o BFS).
     */
    private void displayFoundWords(MyList foundWords, String method) {
        clearResults();
        if (foundWords.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No se encontraron palabras con " + method + ".", "Resultados", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        for (int i = 0; i < foundWords.size(); i++) {
            PalabraEncontrada pe = (PalabraEncontrada) foundWords.get(i);
            resultadosTableModel.addRow(new Object[]{pe.getPalabra(), formatPath(pe.getRuta()), method});
            // También se podrían añadir al diccionario aquí si no están,
            // pero el requisito es para la búsqueda de UNA palabra específica.
            // Para "todas las palabras", el diccionario ya se usa para filtrar
            // qué palabras buscar inicialmente. Si el requisito es añadir CUALQUIER
            // palabra del tablero (incluso si no estaba en el diccionario y se encontró por "todas"),
            // entonces esta lógica también se aplicaría aquí. Por ahora, se mantiene solo en
            // la búsqueda de una palabra específica como se solicitó.
        }
    }

    /**
     * Limpia los resultados de la tabla y el campo de tiempo de ejecución.
     */
    private void clearResults() {
        resultadosTableModel.setRowCount(0); // Eliminar todas las filas
        tiempoEjecucionLabel.setText("Tiempo de Ejecución: N/A");
    }

    /**
     * Formatea la ruta de una palabra encontrada a un String legible.
     * @param path La ruta como int[][].
     * @return Un String formateado de la ruta.
     */
    private String formatPath(int[][] path) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < path.length; i++) {
            sb.append("(").append(path[i][0]).append(",").append(path[i][1]).append(")");
            if (i < path.length - 1) {
                sb.append(" -> ");
            }
        }
        return sb.toString();
    }

    /**
     * Helper para obtener los botones de búsqueda por su texto.
     * Esto es un poco frágil si cambian los textos de los botones o la estructura del layout,
     * pero evita hacer variables de instancia para cada botón.
     * En una app más grande, se asignarían a variables de instancia.
     */
    private JButton getSearchButton(String text) {
        // La jerarquía de componentes puede ser compleja, navegamos por ella para encontrar el botón
        // Este acceso directo asume una estructura de layout específica.
        // En caso de cambios en el layout, esta parte podría necesitar ajustes.
        JPanel searchControls = (JPanel)((JSplitPane)((JSplitPane)getContentPane().getComponent(1)).getRightComponent()).getBottomComponent();
        for (Component comp : searchControls.getComponents()) {
            if (comp instanceof JButton) {
                JButton btn = (JButton) comp;
                if (btn.getText().equals(text)) {
                    return btn;
                }
            }
        }
        return null;
    }

    /**
     * Verifica si el tablero y el diccionario han sido cargados.
     * Muestra un mensaje de advertencia si no lo están.
     * @return true si los datos están cargados, false en caso contrario.
     */
    private boolean checkDataLoaded() {
        if (tablero == null || diccionario == null || buscador == null) {
            JOptionPane.showMessageDialog(this, "Primero debe cargar un archivo con el tablero y el diccionario.", "Datos no cargados", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }
}
