/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sopadeletraskeyvis.datastructures;

/**
 * Una implementación básica de una lista dinámica (ArrayList) sin usar java.util.
 * Permite almacenar objetos de cualquier tipo y crece dinámicamente según sea necesario.
 */
public class MyList {
    private Object[] elements;
    private int size;
    private static final int DEFAULT_CAPACITY = 10;

    /**
     * Constructor que inicializa la lista con una capacidad por defecto.
     */
    public MyList() {
        this.elements = new Object[DEFAULT_CAPACITY];
        this.size = 0;
    }

    /**
     * Agrega un elemento al final de la lista. Si la capacidad es insuficiente,
     * la lista se redimensiona.
     * @param element El elemento a agregar.
     */
    public void add(Object element) {
        if (size == elements.length) {
            resize();
        }
        elements[size++] = element;
    }

    /**
     * Obtiene el elemento en la posición especificada de la lista.
     * @param index El índice del elemento a obtener.
     * @return El elemento en la posición especificada.
     * @throws IndexOutOfBoundsException si el índice está fuera del rango (index < 0 o index >= size).
     */
    public Object get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
        }
        return elements[index];
    }

    /**
     * Elimina el elemento en la posición especificada de la lista.
     * Los elementos posteriores se desplazan a la izquierda.
     * @param index El índice del elemento a eliminar.
     * @return El elemento que fue eliminado de la lista.
     * @throws IndexOutOfBoundsException si el índice está fuera del rango (index < 0 o index >= size).
     */
    public Object remove(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
        }
        Object removedElement = elements[index];
        for (int i = index; i < size - 1; i++) {
            elements[i] = elements[i + 1];
        }
        elements[--size] = null; // Limpiar la última referencia y decrementar el tamaño
        return removedElement;
    }

    /**
     * Devuelve el número de elementos en la lista.
     * @return El número de elementos en la lista.
     */
    public int size() {
        return size;
    }

    /**
     * Verifica si la lista está vacía.
     * @return true si la lista no contiene elementos, false en caso contrario.
     */
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Elimina todos los elementos de la lista.
     */
    public void clear() {
        for (int i = 0; i < size; i++) {
            elements[i] = null;
        }
        size = 0;
    }
    
    /**
     * Convierte la lista a un arreglo de objetos.
     * @return Un arreglo que contiene todos los elementos de la lista en el orden correcto.
     */
    public Object[] toArray() {
        Object[] newArray = new Object[size];
        for (int i = 0; i < size; i++) {
            newArray[i] = elements[i];
        }
        return newArray;
    }

    /**
     * Redimensiona el arreglo interno, duplicando su capacidad.
     */
    private void resize() {
        int newCapacity = elements.length * 2;
        Object[] newElements = new Object[newCapacity];
        for (int i = 0; i < size; i++) {
            newElements[i] = elements[i];
        }
        this.elements = newElements;
    }
}