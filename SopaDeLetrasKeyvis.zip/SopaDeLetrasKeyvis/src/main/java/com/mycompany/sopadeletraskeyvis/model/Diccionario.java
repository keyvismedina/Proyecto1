/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sopadeletraskeyvis.model;

import com.mycompany.sopadeletraskeyvis.datastructures.MyList;

/**
 * Representa un diccionario de palabras para la sopa de letras.
 * Almacena y gestiona las palabras válidas utilizando una implementación de lista propia.
 */
public class Diccionario {
    private MyList palabras; // Almacenará las palabras del diccionario

    /**
     * Constructor que inicializa un diccionario vacío.
     */
    public Diccionario() {
        this.palabras = new MyList();
    }

    /**
     * Agrega una palabra al diccionario si no existe ya y si cumple con la longitud mínima de 3 letras.
     * Las palabras no llevan acento (según el problema).
     * @param palabra La palabra a agregar.
     */
    public void agregarPalabra(String palabra) {
        if (palabra == null || palabra.trim().isEmpty()) {
            return; // No agregar palabras nulas o vacías
        }
        String palabraLimpia = palabra.trim().toUpperCase(); // Convertir a mayúsculas y quitar espacios
        
        // Verificar longitud mínima (al menos 3 letras)
        // Aunque esto debería ser manejado por la lógica de búsqueda de palabras
        // en el tablero, es bueno tenerlo también aquí para consistencia si se agregan
        // palabras manualmente.
        if (palabraLimpia.length() < 3) { // 
            return; 
        }

        // Verificar si la palabra ya existe en el diccionario (búsqueda lineal)
        // NOTA: Para diccionarios muy grandes, esta búsqueda lineal sería ineficiente.
        // Una implementación de tabla hash o Trie propia mejoraría el rendimiento si fuera necesario.
        for (int i = 0; i < palabras.size(); i++) {
            if (palabraLimpia.equals(palabras.get(i))) {
                return; // La palabra ya existe, no la agregamos de nuevo
            }
        }
        palabras.add(palabraLimpia);
    }

    /**
     * Verifica si una palabra existe en el diccionario.
     * @param palabra La palabra a buscar.
     * @return true si la palabra se encuentra en el diccionario, false en caso contrario.
     */
    public boolean existePalabra(String palabra) {
        if (palabra == null || palabra.trim().isEmpty()) {
            return false;
        }
        String palabraLimpia = palabra.trim().toUpperCase();
        for (int i = 0; i < palabras.size(); i++) {
            if (palabraLimpia.equals(palabras.get(i))) {
                return true;
            }
        }
        return false;
    }

    /**
     * Devuelve todas las palabras contenidas en el diccionario como un arreglo de String.
     * @return Un arreglo de String con todas las palabras del diccionario.
     */
    public String[] getTodasLasPalabras() {
        String[] result = new String[palabras.size()];
        for (int i = 0; i < palabras.size(); i++) {
            result[i] = (String) palabras.get(i);
        }
        return result;
    }

    /**
     * Devuelve la cantidad de palabras en el diccionario.
     * @return El número de palabras.
     */
    public int size() {
        return palabras.size();
    }

    /**
     * Imprime todas las palabras del diccionario en la consola (útil para depuración).
     */
    public void imprimirDiccionario() {
        System.out.println("Diccionario:");
        for (int i = 0; i < palabras.size(); i++) {
            System.out.println("- " + palabras.get(i));
        }
    }
}
