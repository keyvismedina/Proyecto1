/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sopadeletraskeyvis.model;

import com.mycompany.sopadeletraskeyvis.datastructures.MyList;
import com.mycompany.sopadeletraskeyvis.datastructures.MyStack; // Para DFS
import com.mycompany.sopadeletraskeyvis.datastructures.MyQueue; // Para BFS
import com.mycompany.sopadeletraskeyvis.datastructures.MyGraph;

/**
 * Clase que contiene la lógica para buscar palabras en el tablero de la sopa de letras
 * utilizando algoritmos de búsqueda como DFS (Depth-First Search) y BFS (Breadth-First Search).
 */
public class BuscadorSopaLetras {

    private Tablero tablero;
    private Diccionario diccionario;

    /**
     * Constructor del buscador de sopa de letras.
     * @param tablero El tablero de letras donde se buscarán las palabras.
     * @param diccionario El diccionario de palabras válidas a encontrar.
     */
    public BuscadorSopaLetras(Tablero tablero, Diccionario diccionario) {
        if (tablero == null) {
            throw new IllegalArgumentException("El tablero no puede ser nulo.");
        }
        if (diccionario == null) {
            throw new IllegalArgumentException("El diccionario no puede ser nulo.");
        }
        this.tablero = tablero;
        this.diccionario = diccionario;
    }

    /**
     * Busca todas las palabras del diccionario en el tablero utilizando el algoritmo DFS.
     * @return Una MyList de objetos PalabraEncontrada que representan las palabras halladas
     * y sus respectivas rutas.
     */
    public MyList buscarTodasLasPalabrasDFS() {
        MyList palabrasEncontradas = new MyList();
        MyGraph grafo = tablero.getGrafoAdyacencia();
        String[] palabrasDiccionario = diccionario.getTodasLasPalabras(); // Podrías usar esto para optimizar si tuvieras un Trie

        for (int fila = 0; fila < tablero.getFilas(); fila++) {
            for (int col = 0; col < tablero.getColumnas(); col++) {
                int startIndex = tablero.toGraphIndex(fila, col);
                
                MyList currentPath = new MyList(); 
                boolean[] visitedArray = new boolean[grafo.getNumVertices()]; // Usado para el backtracking de la recursión DFS

                dfsRecursivo(startIndex, String.valueOf(tablero.getLetra(fila, col)), currentPath, visitedArray, palabrasEncontradas, grafo, palabrasDiccionario);
            }
        }
        return palabrasEncontradas;
    }

    /**
     * Función auxiliar recursiva para el algoritmo DFS.
     * @param currentVertex El índice del vértice actual en el grafo.
     * @param currentWord La palabra formada hasta el momento.
     * @param currentPath La lista de índices de vértices que forman la ruta actual.
     * @param visitedArray Un arreglo booleano para marcar los vértices ya visitados en la ruta actual.
     * @param foundWords La lista donde se almacenarán las palabras encontradas.
     * @param grafo El grafo de adyacencia del tablero.
     * @param diccionarioWords Un arreglo de todas las palabras del diccionario (opcional, para posibles optimizaciones).
     */
    private void dfsRecursivo(int currentVertex, String currentWord, MyList currentPath, boolean[] visitedArray,
                             MyList foundWords, MyGraph grafo, String[] diccionarioWords) {
        
        visitedArray[currentVertex] = true;
        currentPath.add(currentVertex);

        // Convertir el MyList de enteros a un array de int[] para PalabraEncontrada
        // Esto se hace aquí porque si se encuentra una palabra, necesitamos la ruta completa.
        int[][] pathCoords = new int[currentPath.size()][2];
        for (int i = 0; i < currentPath.size(); i++) {
            int vertexIndex = (int) currentPath.get(i);
            pathCoords[i] = tablero.toBoardCoordinates(vertexIndex);
        }

        // Verificar si la palabra actual es válida (>= 3 letras y en el diccionario)
        if (currentWord.length() >= 3 && diccionario.existePalabra(currentWord)) {
            // Verificar si esta palabra ya fue encontrada (por si hay múltiples caminos a la misma palabra)
            boolean alreadyFound = false;
            for (int i = 0; i < foundWords.size(); i++) {
                PalabraEncontrada pe = (PalabraEncontrada) foundWords.get(i);
                if (pe.getPalabra().equals(currentWord)) {
                    alreadyFound = true;
                    break;
                }
            }
            if (!alreadyFound) {
                foundWords.add(new PalabraEncontrada(currentWord, pathCoords));
            }
        }

        // Explorar vecinos
        MyList neighbors = grafo.getNeighbors(currentVertex);
        for (int i = 0; i < neighbors.size(); i++) {
            int neighborVertex = (int) neighbors.get(i);
            // Solo si el vecino no ha sido visitado en esta *ruta actual*
            if (!visitedArray[neighborVertex]) { 
                // Obtener la letra del vecino
                int[] coords = tablero.toBoardCoordinates(neighborVertex);
                char nextChar = tablero.getLetra(coords[0], coords[1]);
                
                dfsRecursivo(neighborVertex, currentWord + nextChar, currentPath, visitedArray, foundWords, grafo, diccionarioWords);
            }
        }

        // Backtrack: Desmarcar el vértice actual y removerlo de la ruta al salir de la recursión
        currentPath.remove(currentPath.size() - 1);
        visitedArray[currentVertex] = false;
    }

    /**
     * Busca todas las palabras del diccionario en el tablero utilizando el algoritmo BFS.
     * Cada palabra debe usar celdas no repetidas en su propia formación.
     * @return Una MyList de objetos PalabraEncontrada que representan las palabras halladas
     * y sus respectivas rutas.
     */
    public MyList buscarTodasLasPalabrasBFS() {
        MyList palabrasEncontradas = new MyList();
        MyGraph grafo = tablero.getGrafoAdyacencia();

        // Iterar sobre cada celda como punto de partida
        for (int fila = 0; fila < tablero.getFilas(); fila++) {
            for (int col = 0; col < tablero.getColumnas(); col++) {
                int startVertex = tablero.toGraphIndex(fila, col);
                
                // Cola para BFS. Cada elemento en la cola será un arreglo de Object:
                // {currentVertex (Integer), currentWord (String), currentPath (MyList de Integer)}
                MyQueue queue = new MyQueue();
                
                // Inicializar el primer elemento en la cola
                MyList initialPath = new MyList();
                initialPath.add(startVertex);
                queue.enqueue(new Object[]{startVertex, String.valueOf(tablero.getLetra(fila, col)), initialPath});

                while (!queue.isEmpty()) {
                    Object[] currentState = (Object[]) queue.dequeue();
                    int currentV = (int) currentState[0];
                    String currentW = (String) currentState[1];
                    MyList pathV = (MyList) currentState[2]; // Ruta hasta el currentV

                    // Convertir la ruta a coordenadas de tablero para PalabraEncontrada
                    int[][] pathCoords = new int[pathV.size()][2];
                    for (int i = 0; i < pathV.size(); i++) {
                        int vertexIndex = (int) pathV.get(i);
                        pathCoords[i] = tablero.toBoardCoordinates(vertexIndex);
                    }

                    // Verificar si la palabra actual es válida (longitud >= 3 y en diccionario)
                    if (currentW.length() >= 3 && diccionario.existePalabra(currentW)) {
                        // Asegurarse de no añadir duplicados de palabras ya encontradas
                        boolean alreadyFound = false;
                        for (int i = 0; i < palabrasEncontradas.size(); i++) {
                            PalabraEncontrada pe = (PalabraEncontrada) palabrasEncontradas.get(i);
                            if (pe.getPalabra().equals(currentW)) {
                                alreadyFound = true;
                                break;
                            }
                        }
                        if (!alreadyFound) {
                            palabrasEncontradas.add(new PalabraEncontrada(currentW, pathCoords));
                        }
                    }
                    
                    // Explorar vecinos del vértice actual
                    MyList neighbors = grafo.getNeighbors(currentV);
                    for (int i = 0; i < neighbors.size(); i++) {
                        int neighborV = (int) neighbors.get(i);
                        
                        // Verificar si el vecino ya está en la ruta actual (para no usar celdas repetidas en la misma palabra)
                        boolean isInCurrentPath = false;
                        for(int k=0; k < pathV.size(); k++){
                            if((int)pathV.get(k) == neighborV){
                                isInCurrentPath = true;
                                break;
                            }
                        }

                        if (!isInCurrentPath) { // Si el vecino no ha sido usado en este camino
                            // Crear un nuevo camino para el vecino, extendiendo el camino actual
                            MyList newPath = new MyList();
                            for (int k = 0; k < pathV.size(); k++) {
                                newPath.add(pathV.get(k));
                            }
                            newPath.add(neighborV);

                            // Obtener la letra del vecino y formar la nueva palabra
                            int[] neighborCoords = tablero.toBoardCoordinates(neighborV);
                            char nextChar = tablero.getLetra(neighborCoords[0], neighborCoords[1]);
                            String newWord = currentW + nextChar;

                            // Añadir el nuevo estado a la cola
                            queue.enqueue(new Object[]{neighborV, newWord, newPath});
                        }
                    }
                }
            }
        }
        return palabrasEncontradas;
    }
    
    /**
     * Busca una palabra específica en el tablero utilizando el algoritmo DFS.
     * @param targetWord La palabra a buscar.
     * @return Un objeto PalabraEncontrada si la palabra es hallada, o null si no se encuentra.
     */
    public PalabraEncontrada buscarPalabraDFS(String targetWord) {
        if (targetWord == null || targetWord.length() < 3) {
            return null;
        }
        String searchWord = targetWord.trim().toUpperCase();

        MyGraph grafo = tablero.getGrafoAdyacencia();

        for (int fila = 0; fila < tablero.getFilas(); fila++) {
            for (int col = 0; col < tablero.getColumnas(); col++) {
                int startIndex = tablero.toGraphIndex(fila, col);
                
                // Si la primera letra no coincide, continuar
                if (tablero.getLetra(fila, col) != searchWord.charAt(0)) {
                    continue;
                }

                MyList currentPath = new MyList();
                boolean[] visitedArray = new boolean[grafo.getNumVertices()];

                // Llamar a la función auxiliar DFS
                PalabraEncontrada result = dfsBuscarPalabraRecursivo(startIndex, String.valueOf(tablero.getLetra(fila, col)), 
                                                                    currentPath, visitedArray, searchWord, grafo);
                if (result != null) {
                    return result; // Palabra encontrada, regresar inmediatamente
                }
            }
        }
        return null; // La palabra no se encontró en ningún inicio
    }

    /**
     * Función auxiliar recursiva para buscar una palabra específica con DFS.
     * @param currentVertex El índice del vértice actual.
     * @param currentWord La palabra formada hasta el momento.
     * @param currentPath La lista de índices de vértices que forman la ruta actual.
     * @param visitedArray Un arreglo booleano para marcar los vértices ya visitados en la ruta actual.
     * @param targetWord La palabra que se está buscando.
     * @param grafo El grafo de adyacencia del tablero.
     * @return Un objeto PalabraEncontrada si la palabra se encuentra, o null.
     */
    private PalabraEncontrada dfsBuscarPalabraRecursivo(int currentVertex, String currentWord, MyList currentPath, 
                                                       boolean[] visitedArray, String targetWord, MyGraph grafo) {
        
        // Marcar el vértice actual como visitado en esta ruta
        visitedArray[currentVertex] = true;
        currentPath.add(currentVertex);

        // Si la palabra actual coincide con la palabra buscada
        if (currentWord.equals(targetWord)) {
            // Convertir el MyList de enteros a un array de int[] para PalabraEncontrada
            int[][] pathCoords = new int[currentPath.size()][2];
            for (int i = 0; i < currentPath.size(); i++) {
                int vertexIndex = (int) currentPath.get(i);
                pathCoords[i] = tablero.toBoardCoordinates(vertexIndex);
            }
            return new PalabraEncontrada(currentWord, pathCoords);
        }

        // Si la palabra actual ya es más larga que la buscada o no es prefijo, no seguir por esta rama
        if (currentWord.length() >= targetWord.length() || !targetWord.startsWith(currentWord)) {
            currentPath.remove(currentPath.size() - 1); // Backtrack
            visitedArray[currentVertex] = false;        // Backtrack
            return null;
        }

        // Explorar vecinos
        MyList neighbors = grafo.getNeighbors(currentVertex);
        for (int i = 0; i < neighbors.size(); i++) {
            int neighborVertex = (int) neighbors.get(i);
            if (!visitedArray[neighborVertex]) { // Si el vecino no ha sido visitado en esta ruta
                int[] coords = tablero.toBoardCoordinates(neighborVertex);
                char nextChar = tablero.getLetra(coords[0], coords[1]);
                
                // Llamada recursiva
                PalabraEncontrada result = dfsBuscarPalabraRecursivo(neighborVertex, currentWord + nextChar, 
                                                                    currentPath, visitedArray, targetWord, grafo);
                if (result != null) {
                    return result; // Si se encontró la palabra, pasarla hacia arriba
                }
            }
        }

        // Si no se encontró la palabra por esta rama, hacer backtrack
        currentPath.remove(currentPath.size() - 1);
        visitedArray[currentVertex] = false;
        return null;
    }

    /**
     * Busca una palabra específica en el tablero utilizando el algoritmo BFS.
     * @param targetWord La palabra a buscar.
     * @return Un objeto PalabraEncontrada si la palabra es hallada, o null si no se encuentra.
     */
    public PalabraEncontrada buscarPalabraBFS(String targetWord) {
        if (targetWord == null || targetWord.length() < 3) {
            return null;
        }
        String searchWord = targetWord.trim().toUpperCase();

        MyGraph grafo = tablero.getGrafoAdyacencia();

        for (int fila = 0; fila < tablero.getFilas(); fila++) {
            for (int col = 0; col < tablero.getColumnas(); col++) {
                int startVertex = tablero.toGraphIndex(fila, col);
                
                // Si la primera letra no coincide, continuar
                if (tablero.getLetra(fila, col) != searchWord.charAt(0)) {
                    continue;
                }

                MyQueue queue = new MyQueue();
                
                // Elemento inicial: {currentVertex, currentWord, currentPath (MyList de Integer)}
                MyList initialPath = new MyList();
                initialPath.add(startVertex);
                queue.enqueue(new Object[]{startVertex, String.valueOf(tablero.getLetra(fila, col)), initialPath});

                while (!queue.isEmpty()) {
                    Object[] currentState = (Object[]) queue.dequeue();
                    int currentV = (int) currentState[0];
                    String currentW = (String) currentState[1];
                    MyList pathV = (MyList) currentState[2];

                    // Si la palabra actual ya es más larga que la buscada o no es prefijo, no seguir
                    if (currentW.length() > targetWord.length() || !targetWord.startsWith(currentW)) {
                        continue; // No necesitamos explorar más por este camino
                    }

                    // Si la palabra actual coincide con la palabra buscada
                    if (currentW.equals(targetWord)) {
                        int[][] pathCoords = new int[pathV.size()][2];
                        for (int i = 0; i < pathV.size(); i++) {
                            int vertexIndex = (int) pathV.get(i);
                            pathCoords[i] = tablero.toBoardCoordinates(vertexIndex);
                        }
                        return new PalabraEncontrada(currentW, pathCoords);
                    }
                    
                    // Explorar vecinos
                    MyList neighbors = grafo.getNeighbors(currentV);
                    for (int i = 0; i < neighbors.size(); i++) {
                        int neighborV = (int) neighbors.get(i);
                        
                        // Verificar si el vecino ya está en la ruta actual (para no usar celdas repetidas en la misma palabra)
                        boolean isInCurrentPath = false;
                        for(int k=0; k < pathV.size(); k++){
                            if((int)pathV.get(k) == neighborV){
                                isInCurrentPath = true;
                                break;
                            }
                        }

                        if (!isInCurrentPath) {
                            MyList newPath = new MyList();
                            for (int k = 0; k < pathV.size(); k++) {
                                newPath.add(pathV.get(k));
                            }
                            newPath.add(neighborV);

                            int[] neighborCoords = tablero.toBoardCoordinates(neighborV);
                            char nextChar = tablero.getLetra(neighborCoords[0], neighborCoords[1]);
                            String newWord = currentW + nextChar;

                            queue.enqueue(new Object[]{neighborV, newWord, newPath});
                        }
                    }
                }
            }
        }
        return null; // La palabra no se encontró
    }
}
