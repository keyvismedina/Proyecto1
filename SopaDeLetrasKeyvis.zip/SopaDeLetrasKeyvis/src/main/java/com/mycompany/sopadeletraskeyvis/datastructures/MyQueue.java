/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sopadeletraskeyvis.datastructures;

/**
 * Una implementación básica de una cola (Queue) sin usar java.util.
 * Sigue el principio FIFO (Primero en entrar, primero en salir).
 */
public class MyQueue {
    private Object[] elements;
    private int front; // Índice del primer elemento
    private int rear;  // Índice de la siguiente posición disponible
    private int size;  // Número actual de elementos en la cola
    private static final int DEFAULT_CAPACITY = 10;

    /**
     * Constructor que inicializa la cola con una capacidad por defecto.
     */
    public MyQueue() {
        this.elements = new Object[DEFAULT_CAPACITY];
        this.front = 0;
        this.rear = 0;
        this.size = 0;
    }

    /**
     * Agrega un elemento al final de la cola (enqueue).
     * Si la capacidad es insuficiente, la cola se redimensiona.
     * @param element El elemento a agregar.
     */
    public void enqueue(Object element) {
        if (size == elements.length) {
            resize();
        }
        elements[rear] = element;
        rear = (rear + 1) % elements.length; // Manejo circular del arreglo
        size++;
    }

    /**
     * Elimina y devuelve el elemento del frente de la cola (dequeue).
     * @return El elemento del frente de la cola.
     * @throws IllegalStateException si la cola está vacía.
     */
    public Object dequeue() {
        if (isEmpty()) {
            throw new IllegalStateException("Queue is empty");
        }
        Object element = elements[front];
        elements[front] = null; // Liberar la referencia
        front = (front + 1) % elements.length; // Manejo circular del arreglo
        size--;
        return element;
    }

    /**
     * Devuelve el elemento del frente de la cola sin eliminarlo (peek).
     * @return El elemento del frente de la cola.
     * @throws IllegalStateException si la cola está vacía.
     */
    public Object peek() {
        if (isEmpty()) {
            throw new IllegalStateException("Queue is empty");
        }
        return elements[front];
    }

    /**
     * Devuelve el número de elementos en la cola.
     * @return El número de elementos en la cola.
     */
    public int size() {
        return size;
    }

    /**
     * Verifica si la cola está vacía.
     * @return true si la cola no contiene elementos, false en caso contrario.
     */
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Redimensiona el arreglo interno, duplicando su capacidad.
     * Mantiene los elementos en el mismo orden lógico.
     */
    private void resize() {
        int newCapacity = elements.length * 2;
        Object[] newElements = new Object[newCapacity];
        // Copiar elementos en el orden correcto al nuevo arreglo
        for (int i = 0; i < size; i++) {
            newElements[i] = elements[(front + i) % elements.length];
        }
        elements = newElements;
        front = 0;
        rear = size; // Rear se convierte en el nuevo 'size' ya que los elementos están contiguos
    }
}
