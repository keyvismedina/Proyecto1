/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sopadeletraskeyvis.utils;

import com.mycompany.sopadeletraskeyvis.model.Tablero;
import com.mycompany.sopadeletraskeyvis.model.Diccionario;
import com.mycompany.sopadeletraskeyvis.datastructures.MyList; // Necesaria para el FileReader interno

import java.io.File;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.FileWriter; // Para guardar el diccionario

/**
 * Clase de utilidad para leer y escribir archivos de texto.
 * Se encarga de cargar el tablero y el diccionario desde un archivo,
 * y de guardar el diccionario en un archivo.
 */
public class FileReader {

    private static final String DIC_START_TAG = "dic";
    private static final String DIC_END_TAG = "/dic";
    private static final String TAB_START_TAG = "tab";
    private static final String TAB_END_TAG = "/tab";

    /**
     * Carga los datos del tablero y el diccionario desde un archivo de texto.
     * El archivo debe seguir el formato especificado con etiquetas "dic" y "tab".
     * @param file El objeto File que apunta al archivo de texto a cargar.
     * @return Un arreglo de Object donde el primer elemento es un Tablero y el segundo es un Diccionario.
     * @throws IOException Si ocurre un error durante la lectura del archivo.
     * @throws IllegalArgumentException Si el formato del archivo es incorrecto o faltan etiquetas.
     */
    public static Object[] cargarDatos(File file) throws IOException, IllegalArgumentException {
        Tablero tablero = null;
        Diccionario diccionario = new Diccionario(); // Inicializarlo para añadir palabras
        
        // Usaremos MyList para almacenar temporalmente las letras del tablero
        MyList tableroCharsList = new MyList(); 
        
        boolean inDicSection = false;
        boolean inTabSection = false;
        int lineNumber = 0;

        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) {
                lineNumber++;
                String trimmedLine = line.trim();

                if (trimmedLine.equalsIgnoreCase(DIC_START_TAG)) {
                    if (inTabSection) throw new IllegalArgumentException("Error en línea " + lineNumber + ": Etiqueta '" + DIC_START_TAG + "' encontrada dentro de sección '" + TAB_START_TAG + "'.");
                    inDicSection = true;
                    continue;
                } else if (trimmedLine.equalsIgnoreCase(DIC_END_TAG)) {
                    if (!inDicSection) throw new IllegalArgumentException("Error en línea " + lineNumber + ": Etiqueta '" + DIC_END_TAG + "' sin etiqueta de inicio.");
                    inDicSection = false;
                    continue;
                } else if (trimmedLine.equalsIgnoreCase(TAB_START_TAG)) {
                    if (inDicSection) throw new IllegalArgumentException("Error en línea " + lineNumber + ": Etiqueta '" + TAB_START_TAG + "' encontrada dentro de sección '" + DIC_START_TAG + "'.");
                    inTabSection = true;
                    continue;
                } else if (trimmedLine.equalsIgnoreCase(TAB_END_TAG)) {
                    if (!inTabSection) throw new IllegalArgumentException("Error en línea " + lineNumber + ": Etiqueta '" + TAB_END_TAG + "' sin etiqueta de inicio.");
                    inTabSection = false;
                    continue;
                }

                if (inDicSection) {
                    if (!trimmedLine.isEmpty()) {
                        diccionario.agregarPalabra(trimmedLine);
                    }
                } else if (inTabSection) {
                    if (!trimmedLine.isEmpty()) {
                        // Las letras del tablero vienen separadas por comas
                        String[] charStrings = trimmedLine.split(",");
                        for (int i = 0; i < charStrings.length; i++) {
                            if (charStrings[i].length() == 1) {
                                tableroCharsList.add(charStrings[i].charAt(0));
                            } else {
                                throw new IllegalArgumentException("Error en línea " + lineNumber + ": Carácter de tablero inválido: '" + charStrings[i] + "'. Se esperaba un solo carácter.");
                            }
                        }
                    }
                }
            }
        }

        // Después de leer todo el archivo, construir el Tablero
        if (tableroCharsList.size() != 16) { // El tablero es de 4x4, por lo tanto 16 letras
            throw new IllegalArgumentException("El tablero debe contener exactamente 16 letras (4x4). Se encontraron " + tableroCharsList.size() + ".");
        }
        char[][] letrasTablero = new char[4][4]; // Hardcodeado a 4x4 según el problema
        for (int i = 0; i < tableroCharsList.size(); i++) {
            letrasTablero[i / 4][i % 4] = (char) tableroCharsList.get(i);
        }
        tablero = new Tablero(letrasTablero);

        if (diccionario.size() == 0) {
            System.out.println("Advertencia: El diccionario cargado está vacío.");
        }

        return new Object[]{tablero, diccionario};
    }

    /**
     * Guarda las palabras del diccionario en un archivo de texto con el formato especificado.
     * @param file El objeto File donde se guardará el diccionario.
     * @param diccionario El objeto Diccionario a guardar.
     * @throws IOException Si ocurre un error durante la escritura del archivo.
     */
    public static void guardarDiccionario(File file, Diccionario diccionario) throws IOException {
        try (FileWriter writer = new FileWriter(file)) {
            writer.write(DIC_START_TAG + "\n");
            String[] palabras = diccionario.getTodasLasPalabras();
            for (String palabra : palabras) {
                writer.write(palabra + "\n");
            }
            writer.write(DIC_END_TAG + "\n");
            // No se guarda el tablero ya que el problema no lo pide y generalmente
            // el tablero es fijo o se carga, no se modifica y guarda.
        }
    }
}
