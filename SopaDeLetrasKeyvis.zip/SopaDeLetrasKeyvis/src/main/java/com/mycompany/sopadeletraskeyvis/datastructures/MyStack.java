/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sopadeletraskeyvis.datastructures;

/**
 * Una implementación básica de una pila (Stack) sin usar java.util.
 * Sigue el principio LIFO (Último en entrar, primero en salir).
 */
public class MyStack {
    private Object[] elements;
    private int top; // Índice del elemento superior
    private static final int DEFAULT_CAPACITY = 10;

    /**
     * Constructor que inicializa la pila con una capacidad por defecto.
     */
    public MyStack() {
        this.elements = new Object[DEFAULT_CAPACITY];
        this.top = -1; // -1 indica que la pila está vacía
    }

    /**
     * Agrega un elemento a la cima de la pila (push).
     * Si la capacidad es insuficiente, la pila se redimensiona.
     * @param element El elemento a agregar.
     */
    public void push(Object element) {
        if (top == elements.length - 1) {
            resize();
        }
        elements[++top] = element;
    }

    /**
     * Elimina y devuelve el elemento de la cima de la pila (pop).
     * @return El elemento de la cima de la pila.
     * @throws IllegalStateException si la pila está vacía.
     */
    public Object pop() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        Object element = elements[top];
        elements[top--] = null; // Liberar la referencia y decrementar top
        return element;
    }

    /**
     * Devuelve el elemento de la cima de la pila sin eliminarlo (peek).
     * @return El elemento de la cima de la pila.
     * @throws IllegalStateException si la pila está vacía.
     */
    public Object peek() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        return elements[top];
    }

    /**
     * Devuelve el número de elementos en la pila.
     * @return El número de elementos en la pila.
     */
    public int size() {
        return top + 1;
    }

    /**
     * Verifica si la pila está vacía.
     * @return true si la pila no contiene elementos, false en caso contrario.
     */
    public boolean isEmpty() {
        return top == -1;
    }

    /**
     * Redimensiona el arreglo interno, duplicando su capacidad.
     */
    private void resize() {
        int newCapacity = elements.length * 2;
        Object[] newElements = new Object[newCapacity];
        for (int i = 0; i <= top; i++) {
            newElements[i] = elements[i];
        }
        this.elements = newElements;
    }
}
