/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sopadeletraskeyvis.utils;

/**
 * Clase de utilidad para medir el tiempo de ejecución de operaciones.
 * Utiliza System.nanoTime() para mayor precisión.
 */
public class Timer {

    private long startTime;
    private long endTime;

    /**
     * Inicia el temporizador.
     * Almacena el tiempo actual en nanosegundos.
     */
    public void start() {
        this.startTime = System.nanoTime();
        this.endTime = 0; // Resetear endTime
    }

    /**
     * Detiene el temporizador.
     * Almacena el tiempo actual en nanosegundos.
     */
    public void stop() {
        this.endTime = System.nanoTime();
    }

    /**
     * Calcula y devuelve el tiempo transcurrido en milisegundos.
     * Si el temporizador no ha sido iniciado y detenido correctamente, devuelve 0.
     * @return El tiempo transcurrido en milisegundos.
     */
    public long getElapsedTimeMillis() {
        if (startTime == 0 || endTime == 0) {
            return 0; // El temporizador no se usó correctamente
        }
        return (endTime - startTime) / 1_000_000; // Convertir nanosegundos a milisegundos
    }
    
    /**
     * Calcula y devuelve el tiempo transcurrido en nanosegundos.
     * Si el temporizador no ha sido iniciado y detenido correctamente, devuelve 0.
     * @return El tiempo transcurrido en nanosegundos.
     */
    public long getElapsedTimeNanos() {
        if (startTime == 0 || endTime == 0) {
            return 0; // El temporizador no se usó correctamente
        }
        return (endTime - startTime);
    }
    
    /**
     * Reinicia el temporizador.
     */
    public void reset() {
        this.startTime = 0;
        this.endTime = 0;
    }
}
