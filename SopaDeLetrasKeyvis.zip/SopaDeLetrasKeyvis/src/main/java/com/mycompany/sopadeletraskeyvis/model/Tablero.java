/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sopadeletraskeyvis.model;

import com.mycompany.sopadeletraskeyvis.datastructures.MyGraph;

/**
 * Representa el tablero de letras de la sopa de letras (4x4).
 * Maneja la matriz de caracteres y puede generar un grafo de adyacencia.
 */
public class Tablero {
    private char[][] letras;
    private MyGraph grafoAdyacencia; // Para representar las conexiones entre letras adyacentes
    private int filas;
    private int columnas;

    /**
     * Constructor del Tablero.
     * @param letras Una matriz 2D de caracteres que representa las letras del tablero.
     * Se espera que sea de 4x4, pero el código es genérico para cualquier tamaño.
     */
    public Tablero(char[][] letras) {
        if (letras == null || letras.length == 0 || letras[0].length == 0) {
            throw new IllegalArgumentException("El tablero de letras no puede estar vacío o ser nulo.");
        }
        this.filas = letras.length;
        this.columnas = letras[0].length;
        this.letras = new char[this.filas][this.columnas];

        // Copiar las letras para asegurar inmutabilidad externa del array pasado
        for (int i = 0; i < this.filas; i++) {
            for (int j = 0; j < this.columnas; j++) {
                this.letras[i][j] = letras[i][j];
            }
        }
        
        // Inicializar el grafo de adyacencia
        // Cada celda (fila, columna) se mapea a un único vértice en el grafo.
        // El mapeo es: indice = fila * num_columnas + columna
        this.grafoAdyacencia = new MyGraph(this.filas * this.columnas);
        conectarAdyacencias();
    }

    /**
     * Conecta las celdas adyacentes en el grafo.
     * Las adyacencias incluyen horizontal, vertical y diagonalmente.
     */
    private void conectarAdyacencias() {
        // Direcciones para adyacencia (8 direcciones: horizontal, vertical, diagonal)
        int[] dr = {-1, -1, -1, 0, 0, 1, 1, 1}; // Cambios en fila
        int[] dc = {-1, 0, 1, -1, 1, -1, 0, 1}; // Cambios en columna

        for (int r = 0; r < filas; r++) {
            for (int c = 0; c < columnas; c++) {
                int verticeActual = toGraphIndex(r, c);

                for (int i = 0; i < 8; i++) {
                    int nr = r + dr[i]; // Nueva fila
                    int nc = c + dc[i]; // Nueva columna

                    // Verificar si la nueva posición es válida dentro del tablero
                    if (nr >= 0 && nr < filas && nc >= 0 && nc < columnas) {
                        int verticeAdyacente = toGraphIndex(nr, nc);
                        grafoAdyacencia.addEdge(verticeActual, verticeAdyacente);
                    }
                }
            }
        }
    }

    /**
     * Convierte una coordenada de fila y columna del tablero a un índice de vértice en el grafo.
     * @param fila La fila en el tablero.
     * @param columna La columna en el tablero.
     * @return El índice del vértice correspondiente en el grafo.
     */
    public int toGraphIndex(int fila, int columna) {
        return fila * columnas + columna;
    }

    /**
     * Convierte un índice de vértice del grafo a las coordenadas (fila, columna) en el tablero.
     * @param index El índice del vértice en el grafo.
     * @return Un arreglo de enteros [fila, columna] que representa las coordenadas en el tablero.
     */
    public int[] toBoardCoordinates(int index) {
        int fila = index / columnas;
        int columna = index % columnas;
        return new int[]{fila, columna};
    }

    /**
     * Obtiene la letra en una posición específica del tablero.
     * @param fila La fila de la letra.
     * @param columna La columna de la letra.
     * @return El carácter de la letra en la posición especificada.
     * @throws IndexOutOfBoundsException si las coordenadas están fuera de rango.
     */
    public char getLetra(int fila, int columna) {
        if (fila < 0 || fila >= filas || columna < 0 || columna >= columnas) {
            throw new IndexOutOfBoundsException("Coordenadas fuera de rango: (" + fila + ", " + columna + ")");
        }
        return letras[fila][columna];
    }

    /**
     * Obtiene el número de filas del tablero.
     * @return El número de filas.
     */
    public int getFilas() {
        return filas;
    }

    /**
     * Obtiene el número de columnas del tablero.
     * @return El número de columnas.
     */
    public int getColumnas() {
        return columnas;
    }

    /**
     * Devuelve la instancia del grafo de adyacencia asociado a este tablero.
     * @return El MyGraph que representa las conexiones de adyacencia.
     */
    public MyGraph getGrafoAdyacencia() {
        return grafoAdyacencia;
    }

    /**
     * Imprime el tablero en la consola (útil para depuración).
     */
    public void imprimirTablero() {
        System.out.println("Tablero:");
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                System.out.print(letras[i][j] + " ");
            }
            System.out.println();
        }
    }
}
