/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/*
 * Clase para leer y escribir archivos de texto. Se usa para cargar el tablero
 * y el diccionario desde un archivo, y también para guardar el diccionario.
 * Los archivos deben seguir un formato específico con etiquetas "dic" y "tab".
 */
package com.mycompany.sopadeletraskeyvis.utils;

import com.mycompany.sopadeletraskeyvis.model.Tablero;
import com.mycompany.sopadeletraskeyvis.model.Diccionario;
import com.mycompany.sopadeletraskeyvis.datastructures.ListaPalabras;

import java.io.File;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.FileWriter;

public class FileReader {

    private static final String DIC_START_TAG = "dic";
    private static final String DIC_END_TAG = "/dic";
    private static final String TAB_START_TAG = "tab";
    private static final String TAB_END_TAG = "/tab";

    /**
     * Carga el tablero y el diccionario desde un archivo. El archivo debe tener
     * las secciones marcadas con "dic" y "tab". Si algo falla, lanza una excepción.
     */
    public static Object[] cargarDatos(File file) throws IOException, IllegalArgumentException {
        Tablero tablero = null;
        Diccionario diccionario = new Diccionario();
        ListaPalabras tableroCharsList = new ListaPalabras();
        
        boolean inDicSection = false;
        boolean inTabSection = false;
        int lineNumber = 0;

        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) {
                lineNumber++;
                String trimmedLine = line.trim();

                if (trimmedLine.equalsIgnoreCase(DIC_START_TAG)) {
                    if (inTabSection) throw new IllegalArgumentException("Error en línea " + lineNumber + ": Etiqueta '" + DIC_START_TAG + "' encontrada dentro de sección '" + TAB_START_TAG + "'.");
                    inDicSection = true;
                    continue;
                } else if (trimmedLine.equalsIgnoreCase(DIC_END_TAG)) {
                    if (!inDicSection) throw new IllegalArgumentException("Error en línea " + lineNumber + ": Etiqueta '" + DIC_END_TAG + "' sin etiqueta de inicio.");
                    inDicSection = false;
                    continue;
                } else if (trimmedLine.equalsIgnoreCase(TAB_START_TAG)) {
                    if (inDicSection) throw new IllegalArgumentException("Error en línea " + lineNumber + ": Etiqueta '" + TAB_START_TAG + "' encontrada dentro de sección '" + DIC_START_TAG + "'.");
                    inTabSection = true;
                    continue;
                } else if (trimmedLine.equalsIgnoreCase(TAB_END_TAG)) {
                    if (!inTabSection) throw new IllegalArgumentException("Error en línea " + lineNumber + ": Etiqueta '" + TAB_END_TAG + "' sin etiqueta de inicio.");
                    inTabSection = false;
                    continue;
                }

                if (inDicSection) {
                    if (!trimmedLine.isEmpty()) {
                        diccionario.agregarPalabra(trimmedLine);
                    }
                } else if (inTabSection) {
                    if (!trimmedLine.isEmpty()) {
                        String[] charStrings = trimmedLine.split(",");
                        for (int i = 0; i < charStrings.length; i++) {
                            if (charStrings[i].length() == 1) {
                                tableroCharsList.add(charStrings[i].charAt(0));
                            } else {
                                throw new IllegalArgumentException("Error en línea " + lineNumber + ": Carácter de tablero inválido: '" + charStrings[i] + "'. Se esperaba un solo carácter.");
                            }
                        }
                    }
                }
            }
        }

        if (tableroCharsList.size() != 16) {
            throw new IllegalArgumentException("El tablero debe contener exactamente 16 letras (4x4). Se encontraron " + tableroCharsList.size() + ".");
        }
        char[][] letrasTablero = new char[4][4];
        for (int i = 0; i < tableroCharsList.size(); i++) {
            letrasTablero[i / 4][i % 4] = (char) tableroCharsList.get(i);
        }
        tablero = new Tablero(letrasTablero);

        if (diccionario.size() == 0) {
            System.out.println("Advertencia: El diccionario cargado está vacío.");
        }

        return new Object[]{tablero, diccionario};
    }

    /**
     * Guarda las palabras del diccionario en un archivo. Solo guarda la sección
     * del diccionario, no el tablero.
     */
    public static void guardarDiccionario(File file, Diccionario diccionario) throws IOException {
        try (FileWriter writer = new FileWriter(file)) {
            writer.write(DIC_START_TAG + "\n");
            String[] palabras = diccionario.getTodasLasPalabras();
            for (String palabra : palabras) {
                writer.write(palabra + "\n");
            }
            writer.write(DIC_END_TAG + "\n");
        }
    }
}