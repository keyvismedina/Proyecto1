/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sopadeletraskeyvis.datastructures;

/**
 * Implementación personalizada de una lista dinámica para almacenar palabras encontradas.
 * Funciona similar a un ArrayList pero con capacidad de crecimiento automático.
 * Se utiliza principalmente para manejar los resultados de búsqueda en el tablero.
 */
public class ListaPalabras {
    private Object[] elements;
    private int size;
    private static final int DEFAULT_CAPACITY = 10;

    /**
     * Crea una nueva lista vacía con capacidad inicial predeterminada.
     * La capacidad irá creciendo según se necesite.
     */
    public ListaPalabras() {
        this.elements = new Object[DEFAULT_CAPACITY];
        this.size = 0;
    }

    /**
     * Añade un nuevo elemento al final de la lista.
     * Si no hay espacio suficiente, la lista se expande automáticamente.
     * @param element Elemento a ser agregado (puede ser una palabra, coordenadas, etc.)
     */
    public void add(Object element) {
        if (size == elements.length) {
            resize();
        }
        elements[size++] = element;
    }

    /**
     * Obtiene el elemento almacenado en una posición específica.
     * @param index Posición del elemento deseado (comenzando desde 0)
     * @return El elemento solicitado
     * @throws IndexOutOfBoundsException Si se solicita una posición inválida
     */
    public Object get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
        }
        return elements[index];
    }

    /**
     * Elimina un elemento de la lista y ajusta las posiciones restantes.
     * @param index Posición del elemento a eliminar
     * @return El elemento que fue removido
     * @throws IndexOutOfBoundsException Si se solicita eliminar una posición inválida
     */
    public Object remove(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
        }
        Object removedElement = elements[index];
        for (int i = index; i < size - 1; i++) {
            elements[i] = elements[i + 1];
        }
        elements[--size] = null; // Ayuda al recolector de basura liberando la referencia
        return removedElement;
    }

    /**
     * Indica cuántos elementos contiene actualmente la lista.
     * @return Número total de elementos almacenados
     */
    public int size() {
        return size;
    }

    /**
     * Verifica si la lista no contiene ningún elemento.
     * @return true si está vacía, false si tiene al menos un elemento
     */
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Vacía completamente la lista, eliminando todos sus elementos.
     */
    public void clear() {
        for (int i = 0; i < size; i++) {
            elements[i] = null;
        }
        size = 0;
    }
    
    /**
     * Convierte la lista en un arreglo estándar de Java.
     * @return Arreglo con todos los elementos en el mismo orden
     */
    public Object[] toArray() {
        Object[] newArray = new Object[size];
        for (int i = 0; i < size; i++) {
            newArray[i] = elements[i];
        }
        return newArray;
    }

    /**
     * Método interno para aumentar la capacidad de almacenamiento.
     * Duplica el tamaño actual del arreglo subyacente.
     */
    private void resize() {
        int newCapacity = elements.length * 2;
        Object[] newElements = new Object[newCapacity];
        for (int i = 0; i < size; i++) {
            newElements[i] = elements[i];
        }
        this.elements = newElements;
    }
}