/*
 * Este es el archivo principal de la interfaz gráfica para el juego de Sopa de Letras.
 * Creado como parte del proyecto Keyvis, permite cargar archivos, buscar palabras y mostrar resultados.
 */
package com.mycompany.sopadeletraskeyvis.gui;

import com.mycompany.sopadeletraskeyvis.model.Tablero;
import com.mycompany.sopadeletraskeyvis.model.Diccionario;
import com.mycompany.sopadeletraskeyvis.model.BuscadorSopaLetras;
import com.mycompany.sopadeletraskeyvis.model.PalabraEncontrada;
import com.mycompany.sopadeletraskeyvis.utils.FileReader;
import com.mycompany.sopadeletraskeyvis.utils.Timer;
import com.mycompany.sopadeletraskeyvis.datastructures.ListaPalabras;
import com.mycompany.sopadeletraskeyvis.utils.VisArbol;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

/**
 * Clase principal de la interfaz gráfica. Aquí se maneja todo lo relacionado con la visualización
 * y la interacción del usuario, como cargar archivos, mostrar el tablero y buscar palabras.
 */
public class Main extends JFrame {

    // Estos son los componentes principales del programa:
    // - tablero: guarda las letras de la sopa.
    // - diccionario: contiene las palabras que se deben buscar.
    // - buscador: se encarga de encontrar las palabras en el tablero.
    private Tablero tablero;
    private Diccionario diccionario;
    private BuscadorSopaLetras buscador;

    // Componentes de la interfaz gráfica:
    private JTextArea tableroTextArea;          // Muestra el tablero de letras.
    private JTextArea diccionarioTextArea;      // Muestra las palabras del diccionario.
    private JLabel tiempoEjecucionLabel;        // Indica cuánto tiempo tomó una búsqueda.
    private JTextField buscarPalabraField;      // Campo para escribir la palabra a buscar.

    // Tabla para mostrar los resultados de las búsquedas:
    private JTable resultadosTable;
    private DefaultTableModel resultadosTableModel;

    // Estos paneles con scroll ayudan a ver el contenido si es muy grande:
    private JScrollPane tableroScrollPane;
    private JScrollPane diccionarioScrollPane;
    private JScrollPane resultadosScrollPane;

    /**
     * Constructor de la clase. Configura la ventana principal y sus componentes.
     */
    public Main() {
        setTitle("Sopa de Letras Keyvis");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centra la ventana en la pantalla.

        initComponents();     // Inicializa los componentes gráficos.
        setupLayout();        // Organiza cómo se ven los componentes.
        addListeners();       // Agrega las acciones a los botones.
    }

    /**
     * Inicializa todos los componentes gráficos, como áreas de texto, botones y la tabla.
     */
    private void initComponents() {
        // Configura el área donde se muestra el tablero:
        tableroTextArea = new JTextArea(5, 20);
        tableroTextArea.setEditable(false);
        tableroTextArea.setFont(new Font("Monospaced", Font.BOLD, 20));
        tableroTextArea.setBorder(BorderFactory.createTitledBorder("Tablero (4x4)"));
        tableroScrollPane = new JScrollPane(tableroTextArea);

        // Configura el área del diccionario:
        diccionarioTextArea = new JTextArea(10, 20);
        diccionarioTextArea.setEditable(false);
        diccionarioTextArea.setBorder(BorderFactory.createTitledBorder("Diccionario"));
        diccionarioScrollPane = new JScrollPane(diccionarioTextArea);

        // Campo para que el usuario escriba qué palabra quiere buscar:
        buscarPalabraField = new JTextField(20);
        buscarPalabraField.setBorder(BorderFactory.createTitledBorder("Buscar palabra específica"));

        // Configura la tabla de resultados con sus columnas:
        String[] columnNames = {"Palabra", "Ruta", "Método"};
        resultadosTableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Evita que el usuario edite la tabla.
            }
        };
        resultadosTable = new JTable(resultadosTableModel);
        resultadosTable.setFont(new Font("Monospaced", Font.PLAIN, 12));
        resultadosTable.setRowHeight(20);
        resultadosScrollPane = new JScrollPane(resultadosTable);
        resultadosScrollPane.setBorder(BorderFactory.createTitledBorder("Resultados de Búsqueda"));
        
        tiempoEjecucionLabel = new JLabel("Tiempo de Ejecución: N/A");
        tiempoEjecucionLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        
    }

    /**
     * Define cómo se organizan los componentes en la ventana.
     */
    private void setupLayout() {
        setLayout(new BorderLayout(10, 10)); // Margen entre componentes.

        // Panel superior con el botón para cargar archivos:
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton cargarArchivoButton = new JButton("Cargar Archivo");
        topPanel.add(cargarArchivoButton);
        add(topPanel, BorderLayout.NORTH);

        // Panel central dividido en dos partes:
        JSplitPane centerSplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        centerSplitPane.setResizeWeight(0.3); // El tablero y diccionario ocupan el 30%.
        
        // Panel izquierdo con el tablero y el diccionario:
        JPanel leftPanel = new JPanel(new GridLayout(2, 1, 10, 10));
        leftPanel.add(tableroScrollPane);
        leftPanel.add(diccionarioScrollPane);
        
        // Panel derecho dividido en resultados y controles de búsqueda:
        JSplitPane rightSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        rightSplitPane.setResizeWeight(0.7); // Los resultados ocupan el 70%.
        rightSplitPane.setTopComponent(resultadosScrollPane);
        
        // Panel inferior con los botones de búsqueda y el tiempo de ejecución:
        JPanel searchControlsPanel = new JPanel();
        searchControlsPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); // Padding.

        // Agrega los componentes al panel de controles:
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.HORIZONTAL;
        searchControlsPanel.add(buscarPalabraField, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1; gbc.fill = GridBagConstraints.NONE;
        JButton buscarDFSButton = new JButton("Buscar Palabra (DFS)");
        searchControlsPanel.add(buscarDFSButton, gbc);

        gbc.gridx = 1; gbc.gridy = 1;
        JButton buscarBFSButton = new JButton("Buscar Palabra (BFS)");
        searchControlsPanel.add(buscarBFSButton, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 1;
        JButton buscarTodasDFSButton = new JButton("Todas las Palabras (DFS)");
        searchControlsPanel.add(buscarTodasDFSButton, gbc);

        gbc.gridx = 1; gbc.gridy = 2;
        JButton buscarTodasBFSButton = new JButton("Todas las Palabras (BFS)");
        searchControlsPanel.add(buscarTodasBFSButton, gbc);

        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.HORIZONTAL;
        JButton guardarDiccionarioButton = new JButton("Guardar Diccionario");
        searchControlsPanel.add(guardarDiccionarioButton, gbc);

        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.HORIZONTAL;
        searchControlsPanel.add(tiempoEjecucionLabel, gbc);
        
        rightSplitPane.setBottomComponent(searchControlsPanel);

        centerSplitPane.setLeftComponent(leftPanel);
        centerSplitPane.setRightComponent(rightSplitPane);
        
        add(centerSplitPane, BorderLayout.CENTER);
    }

    /**
     * Agrega las acciones a los botones y campos de texto.
     */
    private void addListeners() {
        // Acción para cargar un archivo:
        ((JButton)((JPanel)getContentPane().getComponent(0)).getComponent(0)).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setCurrentDirectory(new File(".")); // Abre en el directorio actual.
                int result = fileChooser.showOpenDialog(Main.this);
                if (result == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();
                    try {
                        Object[] data = FileReader.cargarDatos(selectedFile);
                        tablero = (Tablero) data[0];
                        diccionario = (Diccionario) data[1];
                        buscador = new BuscadorSopaLetras(tablero, diccionario);
                        displayTablero();
                        displayDiccionario();
                        clearResults();
                        JOptionPane.showMessageDialog(Main.this, "Archivo cargado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    } catch (IOException | IllegalArgumentException ex) {
                        JOptionPane.showMessageDialog(Main.this, "Error al cargar archivo: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                        tablero = null;
                        diccionario = null;
                        buscador = null;
                        tableroTextArea.setText("");
                        diccionarioTextArea.setText("");
                        clearResults();
                    }
                }
            }
        });

        // Acción para buscar una palabra con DFS:
        getSearchButton("Buscar Palabra (DFS)").addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!checkDataLoaded()) return;
                clearResults();
                String targetWord = buscarPalabraField.getText().trim().toUpperCase();
                if (targetWord.isEmpty()) { 
                    JOptionPane.showMessageDialog(Main.this, "Por favor, ingrese la palabra a buscar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                Timer timer = new Timer();
                timer.start();
                PalabraEncontrada found = buscador.buscarPalabraDFS(targetWord);
                timer.stop();
                tiempoEjecucionLabel.setText("Tiempo de Ejecución (DFS - una palabra): " + timer.getElapsedTimeMillis() + " ms");
                
                if (found != null) {
                    resultadosTableModel.addRow(new Object[]{found.getPalabra(), formatPath(found.getRuta()), "DFS (Una)"});
                    // Si la palabra no está en el diccionario, se agrega:
                    if (!diccionario.existePalabra(found.getPalabra())) {
                        diccionario.agregarPalabra(found.getPalabra());
                        displayDiccionario();
                        JOptionPane.showMessageDialog(Main.this, "Palabra '" + found.getPalabra() + "' encontrada y agregada al diccionario.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(Main.this, "Palabra '" + found.getPalabra() + "' encontrada (ya estaba en el diccionario).", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(Main.this, "La palabra '" + targetWord + "' no se encontró con DFS.", "Resultado", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        // Acción para buscar una palabra con BFS:
        getSearchButton("Buscar Palabra (BFS)").addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!checkDataLoaded()) return;
                
                String targetWord = buscarPalabraField.getText().trim().toUpperCase();
                if (targetWord.isEmpty()) {
                    JOptionPane.showMessageDialog(Main.this,
                        "Por favor, ingrese una palabra para buscar",
                        "Advertencia", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                Timer timer = new Timer();
                timer.start();
                PalabraEncontrada foundWord = buscador.buscarPalabraBFS(targetWord);
                timer.stop();
                tiempoEjecucionLabel.setText("Tiempo de Ejecución (BFS - una palabra): " + timer.getElapsedTimeMillis() + " ms");
                
                if (foundWord != null) {
                    resultadosTableModel.addRow(new Object[]{
                        foundWord.getPalabra(),
                        formatPath(foundWord.getRuta()),
                        "BFS (Una)"
                    });
                    
                    boolean palabraExistente = diccionario.existePalabra(foundWord.getPalabra());
                    
                    if (!palabraExistente) {
                        diccionario.agregarPalabra(foundWord.getPalabra());
                        displayDiccionario();
                        JOptionPane.showMessageDialog(Main.this, 
                            "Palabra '" + foundWord.getPalabra() + "' encontrada y agregada al diccionario.", 
                            "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(Main.this,
                            "Palabra '" + foundWord.getPalabra() + "' encontrada (ya estaba en el diccionario).",
                            "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    }
                    
                    // Muestra el árbol de búsqueda gráficamente:
                    VisArbol.mostrarArbolGrafico(foundWord, tablero);
                    
                } else {
                    JOptionPane.showMessageDialog(Main.this,
                        "La palabra '" + targetWord + "' no se encontró con BFS.",
                        "Resultado", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
        
        // Acción para buscar todas las palabras con DFS:
        getSearchButton("Todas las Palabras (DFS)").addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!checkDataLoaded()) return;
                clearResults();
                Timer timer = new Timer();
                timer.start();
                ListaPalabras foundWords = buscador.buscarTodasLasPalabrasDFS();
                timer.stop();
                tiempoEjecucionLabel.setText("Tiempo de Ejecución (DFS - todas): " + timer.getElapsedTimeMillis() + " ms");
                displayFoundWords(foundWords, "DFS (Todas)");
            }
        });

        // Acción para buscar todas las palabras con BFS:
        getSearchButton("Todas las Palabras (BFS)").addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!checkDataLoaded()) return;
                clearResults();
                Timer timer = new Timer();
                timer.start();
                ListaPalabras foundWords = buscador.buscarTodasLasPalabrasBFS();
                timer.stop();
                tiempoEjecucionLabel.setText("Tiempo de Ejecución (BFS - todas): " + timer.getElapsedTimeMillis() + " ms");
                displayFoundWords(foundWords, "BFS (Todas)");
            }
        });

        // Acción para guardar el diccionario en un archivo:
        getSearchButton("Guardar Diccionario").addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (diccionario == null) {
                    JOptionPane.showMessageDialog(Main.this, "No hay diccionario cargado para guardar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setCurrentDirectory(new File("."));
                fileChooser.setDialogTitle("Guardar Diccionario como...");
                int userSelection = fileChooser.showSaveDialog(Main.this);

                if (userSelection == JFileChooser.APPROVE_OPTION) {
                    File fileToSave = fileChooser.getSelectedFile();
                    try {
                        FileReader.guardarDiccionario(fileToSave, diccionario);
                        JOptionPane.showMessageDialog(Main.this, "Diccionario guardado exitosamente en: " + fileToSave.getAbsolutePath(), "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    } catch (IOException ex) {
                        JOptionPane.showMessageDialog(Main.this, "Error al guardar el diccionario: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        }); 
    }

    /**
     * Muestra el tablero en el área de texto correspondiente.
     */
    private void displayTablero() {
        if (tablero == null) {
            tableroTextArea.setText("No hay tablero cargado.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < tablero.getFilas(); i++) {
            for (int j = 0; j < tablero.getColumnas(); j++) {
                sb.append(tablero.getLetra(i, j)).append("  ");
            }
            sb.append("\n");
        }
        tableroTextArea.setText(sb.toString());
    }

    /**
     * Muestra el diccionario en el área de texto correspondiente.
     */
    private void displayDiccionario() {
        if (diccionario == null) {
            diccionarioTextArea.setText("No hay diccionario cargado.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        String[] palabras = diccionario.getTodasLasPalabras();
        if (palabras.length == 0) {
            sb.append("Diccionario vacío.");
        } else {
            for (String palabra : palabras) {
                sb.append("- ").append(palabra).append("\n");
            }
        }
        diccionarioTextArea.setText(sb.toString());
        diccionarioTextArea.setCaretPosition(diccionarioTextArea.getDocument().getLength());
    }

    /**
     * Muestra las palabras encontradas en la tabla de resultados.
     * @param foundWords Lista de palabras encontradas.
     * @param method Método de búsqueda usado (DFS o BFS).
     */
    private void displayFoundWords(ListaPalabras foundWords, String method) {
        clearResults();
        if (foundWords.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No se encontraron palabras con " + method + ".", "Resultados", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        for (int i = 0; i < foundWords.size(); i++) {
            PalabraEncontrada pe = (PalabraEncontrada) foundWords.get(i);
            resultadosTableModel.addRow(new Object[]{pe.getPalabra(), formatPath(pe.getRuta()), method});
        }
    }

    /**
     * Limpia la tabla de resultados y el tiempo de ejecución.
     */
    private void clearResults() {
        resultadosTableModel.setRowCount(0);
        tiempoEjecucionLabel.setText("Tiempo de Ejecución: N/A");
    }

    /**
     * Convierte la ruta de una palabra en un String legible.
     * @param path Matriz con las coordenadas de la ruta.
     * @return String formateado de la ruta.
     */
    private String formatPath(int[][] path) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < path.length; i++) {
            sb.append("(").append(path[i][0]).append(",").append(path[i][1]).append(")");
            if (i < path.length - 1) {
                sb.append(" -> ");
            }
        }
        return sb.toString();
    }

    /**
     * Busca un botón en la interfaz por su texto.
     * @param text Texto del botón.
     * @return El botón encontrado o null si no existe.
     */
    private JButton getSearchButton(String text) {
        JPanel searchControls = (JPanel)((JSplitPane)((JSplitPane)getContentPane().getComponent(1)).getRightComponent()).getBottomComponent();
        for (Component comp : searchControls.getComponents()) {
            if (comp instanceof JButton) {
                JButton btn = (JButton) comp;
                if (btn.getText().equals(text)) {
                    return btn;
                }
            }
        }
        return null;
    }

    /**
     * Verifica si el tablero y el diccionario están cargados.
     * @return true si están cargados, false si no.
     */
    private boolean checkDataLoaded() {
        if (tablero == null || diccionario == null || buscador == null) {
            JOptionPane.showMessageDialog(this, "Primero debe cargar un archivo con el tablero y el diccionario.", "Datos no cargados", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }
}