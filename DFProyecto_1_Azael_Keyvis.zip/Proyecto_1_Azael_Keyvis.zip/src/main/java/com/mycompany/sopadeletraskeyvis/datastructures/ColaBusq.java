/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sopadeletraskeyvis.datastructures;

/**
 * Implementación de una cola para el algoritmo BFS.
 * Sigue el principio FIFO (primero en entrar, primero en salir).
 * Utiliza un esquema circular para optimizar el uso de memoria.
 */
public class ColaBusq {
    private Object[] elements;
    private int front;
    private int rear;
    private int size;
    private static final int DEFAULT_CAPACITY = 10;

    /**
     * Crea una nueva cola vacía con capacidad inicial estándar.
     * Los punteros front y rear comienzan en la misma posición.
     */
    public ColaBusq() {
        this.elements = new Object[DEFAULT_CAPACITY];
        this.front = 0;
        this.rear = 0;
        this.size = 0;
    }

    /**
     * Encola un nuevo elemento al final de la cola.
     * Maneja automáticamente la expansión de capacidad cuando es necesario.
     * @param element Elemento a ser encolado 
     */
    public void enqueue(Object element) {
        if (size == elements.length) {
            resize();
        }
        elements[rear] = element;
        rear = (rear + 1) % elements.length; // Manejo circular
        size++;
    }

    /**
     * Desencola y devuelve el elemento del frente de la cola.
     * @return El elemento más antiguo de la cola
     * @throws IllegalStateException Si se intenta desencolar cuando la cola está vacía
     */
    public Object dequeue() {
        if (isEmpty()) {
            throw new IllegalStateException("Queue is empty");
        }
        Object element = elements[front];
        elements[front] = null; // Elimina la referencia
        front = (front + 1) % elements.length; // Manejo circular
        size--;
        return element;
    }

    /**
     * Permite ver el elemento del frente sin removerlo de la cola.
     * @return El próximo elemento que saldría al desencolar
     * @throws IllegalStateException Si la cola está vacía
     */
    public Object peek() {
        if (isEmpty()) {
            throw new IllegalStateException("Queue is empty");
        }
        return elements[front];
    }

    /**
     * Indica cuántos elementos hay actualmente en la cola.
     * @return Cantidad total de elementos en cola
     */
    public int size() {
        return size;
    }

    /**
     * Determina si la cola no contiene elementos.
     * @return true si está vacía, false si tiene elementos
     */
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Método interno para duplicar la capacidad de almacenamiento.
     * Reorganiza los elementos para mantener el orden.
     */
    private void resize() {
        int newCapacity = elements.length * 2;
        Object[] newElements = new Object[newCapacity];
        for (int i = 0; i < size; i++) {
            newElements[i] = elements[(front + i) % elements.length];
        }
        elements = newElements;
        front = 0;
        rear = size;
    }
}