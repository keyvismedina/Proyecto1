/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/*
 * Clase que representa una palabra encontrada en el tablero.
 * Incluye la palabra y la ruta de coordenadas donde se encontró.
 */
package com.mycompany.sopadeletraskeyvis.model;

public class PalabraEncontrada {
    private String palabra;
    private int[][] ruta; // Cada posición guarda {fila, columna}.

    /**
     * Crea una palabra encontrada.
     * @param palabra La palabra hallada.
     * @param ruta Las coordenadas donde está la palabra en el tablero.
     */
    public PalabraEncontrada(String palabra, int[][] ruta) {
        if (palabra == null || palabra.isEmpty()) {
            throw new IllegalArgumentException("La palabra no puede estar vacía.");
        }
        if (ruta == null || ruta.length == 0) {
            throw new IllegalArgumentException("La ruta no puede estar vacía.");
        }
        this.palabra = palabra;
        this.ruta = new int[ruta.length][2];
        for (int i = 0; i < ruta.length; i++) {
            this.ruta[i][0] = ruta[i][0];
            this.ruta[i][1] = ruta[i][1];
        }
    }

    /**
     * Obtiene la palabra encontrada.
     * @return La palabra como String.
     */
    public String getPalabra() {
        return palabra;
    }

    /**
     * Obtiene la ruta de la palabra en el tablero.
     * @return Un arreglo con las coordenadas {fila, columna}.
     */
    public int[][] getRuta() {
        int[][] rutaCopia = new int[ruta.length][2];
        for (int i = 0; i < ruta.length; i++) {
            rutaCopia[i][0] = ruta[i][0];
            rutaCopia[i][1] = ruta[i][1];
        }
        return rutaCopia;
    }

    /**
     * Representación en texto de la palabra encontrada.
     * @return Un String con la palabra y su ruta.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Palabra: ").append(palabra).append(", Ruta: [");
        for (int i = 0; i < ruta.length; i++) {
            sb.append("(").append(ruta[i][0]).append(",").append(ruta[i][1]).append(")");
            if (i < ruta.length - 1) {
                sb.append(" -> ");
            }
        }
        sb.append("]");
        return sb.toString();
    }
}