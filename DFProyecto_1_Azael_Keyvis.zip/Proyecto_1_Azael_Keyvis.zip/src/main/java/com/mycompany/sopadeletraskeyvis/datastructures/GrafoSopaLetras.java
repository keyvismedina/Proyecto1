package com.mycompany.sopadeletraskeyvis.datastructures;

/**
 * Implementación básica de un grafo no dirigido implementado usando una matriz de adyacencia.
 * Lo usaremos para representar las conexiones entre letras en el tablero.
 * Aún estoy aprendiendo sobre grafos, pero esto parece un buen comienzo.
 */
public class GrafoSopaLetras {
    // La matriz de adyacencia - true significa que hay conexión entre nodos
    private boolean[][] adjMatrix;
    private int numVertices; // Cantidad total de nodos en nuestro grafo

    /**
     * Crea un nuevo grafo con cierta cantidad de nodos
     * @param numVertices Cuántos nodos tendrá nuestro grafo
     */
    public GrafoSopaLetras(int numVertices) {
        this.numVertices = numVertices;
        // Inicializamos todas las conexiones como false (sin aristas al principio)
        this.adjMatrix = new boolean[numVertices][numVertices];
    }

    /**
     * Conecta dos nodos en el grafo. Como es no dirigido,
     * añadimos la conexión en ambos sentidos.
     * @param v1 Primer nodo a conectar
     * @param v2 Segundo nodo a conectar
     */
    public void addEdge(int v1, int v2) {
        // Primero verificamos que los nodos existan
        if (v1 >= 0 && v1 < numVertices && v2 >= 0 && v2 < numVertices) {
            adjMatrix[v1][v2] = true;
            adjMatrix[v2][v1] = true; // Conexión bidireccional
        } else {
            System.err.println("Error: Nodos fuera de rango (" + v1 + ", " + v2 + ")");
        }
    }

    /**
     * Elimina una conexión entre dos nodos
     * @param v1 Primer nodo
     * @param v2 Segundo nodo
     */
    public void removeEdge(int v1, int v2) {
        if (v1 >= 0 && v1 < numVertices && v2 >= 0 && v2 < numVertices) {
            adjMatrix[v1][v2] = false;
            adjMatrix[v2][v1] = false;
        } else {
            System.err.println("Error: Nodos fuera de rango (" + v1 + ", " + v2 + ")");
        }
    }

    /**
     * Revisa si dos nodos están conectados
     * @param v1 Primer nodo
     * @param v2 Segundo nodo
     * @return true si están conectados, false si no
     */
    public boolean hasEdge(int v1, int v2) {
        if (v1 >= 0 && v1 < numVertices && v2 >= 0 && v2 < numVertices) {
            return adjMatrix[v1][v2];
        }
        return false;
    }

    /**
     * @return La cantidad total de nodos en el grafo
     */
    public int getNumVertices() {
        return numVertices;
    }

    /**
     * Obtiene todos los nodos vecinos de un nodo dado
     * @param v El nodo del que queremos vecinos
     * @return Lista con los índices de los nodos adyacentes
     */
    public ListaPalabras getNeighbors(int v) {
        ListaPalabras neighbors = new ListaPalabras();
        if (v >= 0 && v < numVertices) {
            // Revisamos toda la fila en la matriz de adyacencia
            for (int i = 0; i < numVertices; i++) {
                if (adjMatrix[v][i]) {
                    neighbors.add(i);
                }
            }
        } else {
            System.err.println("Error: Nodo fuera de rango (" + v + ")");
        }
        return neighbors;
    }
}