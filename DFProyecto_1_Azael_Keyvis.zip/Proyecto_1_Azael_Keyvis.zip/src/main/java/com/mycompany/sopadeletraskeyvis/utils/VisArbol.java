/*
 * Clase para mostrar gráficamente cómo se encontró una palabra en el tablero.
 * Usa una librería externa (GraphStream) para dibujar nodos y conexiones.
 */
package com.mycompany.sopadeletraskeyvis.utils;

import com.mycompany.sopadeletraskeyvis.model.Tablero;
import com.mycompany.sopadeletraskeyvis.model.PalabraEncontrada;
import org.graphstream.graph.*;
import org.graphstream.graph.implementations.*;
import org.graphstream.ui.view.Viewer;
import javax.swing.*;

public class VisArbol {
    
    /**
     * Muestra una ventana con el recorrido que hizo el algoritmo para encontrar
     * una palabra en el tablero. Cada nodo es una letra y las flechas muestran
     * el camino seguido.
     */
    public static void mostrarArbolGrafico(PalabraEncontrada palabra, Tablero tablero) {
        System.setProperty("org.graphstream.ui", "swing");
        
        Graph grafo = new SingleGraph("Recorrido BFS: " + palabra.getPalabra());
        grafo.setAttribute("ui.quality");
        grafo.setAttribute("ui.antialias");
        
        String estiloCSS = """
            node {
                size: 35px;
                fill-color: #A3C4F3;
                text-size: 14;
                text-alignment: center;
                text-style: bold;
                stroke-mode: plain;
                stroke-color: #333;
                stroke-width: 2px;
            }
            node.raiz {
                fill-color: #6EEB83;
                size: 40px;
            }
            edge {
                fill-color: #777;
                size: 2px;
                arrow-shape: arrow;
                arrow-size: 10px;
            }
        """;
        grafo.setAttribute("ui.stylesheet", estiloCSS);
        
        try {
            for (int i = 0; i < palabra.getRuta().length; i++) {
                int fila = palabra.getRuta()[i][0];
                int columna = palabra.getRuta()[i][1];
                char letra = tablero.getLetra(fila, columna);
                
                String idNodo = "N" + fila + "-" + columna;
                Node nodo = grafo.addNode(idNodo);
                nodo.setAttribute("ui.label", letra + "\n(" + fila + "," + columna + ")");
                
                if (i == 0) {
                    nodo.setAttribute("ui.class", "raiz");
                }
                
                if (i > 0) {
                    int filaAnterior = palabra.getRuta()[i-1][0];
                    int columnaAnterior = palabra.getRuta()[i-1][1];
                    String idNodoAnterior = "N" + filaAnterior + "-" + columnaAnterior;
                    grafo.addEdge(idNodoAnterior + "-" + idNodo, idNodoAnterior, idNodo, true);
                }
            }
            
            Viewer viewer = grafo.display();
            viewer.setCloseFramePolicy(Viewer.CloseFramePolicy.HIDE_ONLY);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,
                "Error al visualizar el árbol: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}