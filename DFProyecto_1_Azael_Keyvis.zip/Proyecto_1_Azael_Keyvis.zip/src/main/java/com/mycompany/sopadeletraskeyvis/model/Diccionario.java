/*
 * Clase que representa un diccionario de palabras para la sopa de letras.
 * Guarda las palabras válidas que se pueden encontrar en el tablero.
 */
package com.mycompany.sopadeletraskeyvis.model;

import com.mycompany.sopadeletraskeyvis.datastructures.ListaPalabras;

public class Diccionario {
    private ListaPalabras palabras; // Aquí se guardan las palabras del diccionario.

    /**
     * Crea un diccionario vacío.
     */
    public Diccionario() {
        this.palabras = new ListaPalabras();
    }

    /**
     * Añade una palabra al diccionario si cumple las condiciones.
     * @param palabra La palabra que se quiere añadir.
     */
    public void agregarPalabra(String palabra) {
        if (palabra == null || palabra.trim().isEmpty()) {
            return; // No se añaden palabras vacías o nulas.
        }
        String palabraLimpia = palabra.trim().toUpperCase();
        
        if (palabraLimpia.length() < 3) {
            return; // Las palabras deben tener al menos 3 letras.
        }

        for (int i = 0; i < palabras.size(); i++) {
            if (palabraLimpia.equals(palabras.get(i))) {
                return; // La palabra ya existe en el diccionario.
            }
        }
        palabras.add(palabraLimpia);
    }

    /**
     * Revisa si una palabra está en el diccionario.
     * @param palabra La palabra a buscar.
     * @return true si la palabra está, false si no.
     */
    public boolean existePalabra(String palabra) {
        if (palabra == null || palabra.trim().isEmpty()) {
            return false;
        }
        String palabraLimpia = palabra.trim().toUpperCase();
        for (int i = 0; i < palabras.size(); i++) {
            if (palabraLimpia.equals(palabras.get(i))) {
                return true;
            }
        }
        return false;
    }

    /**
     * Obtiene todas las palabras del diccionario.
     * @return Un arreglo con todas las palabras.
     */
    public String[] getTodasLasPalabras() {
        String[] result = new String[palabras.size()];
        for (int i = 0; i < palabras.size(); i++) {
            result[i] = (String) palabras.get(i);
        }
        return result;
    }

    /**
     * Devuelve la cantidad de palabras en el diccionario.
     * @return El número de palabras.
     */
    public int size() {
        return palabras.size();
    }

    /**
     * Imprime el diccionario en la consola (útil para pruebas).
     */
    public void imprimirDiccionario() {
        System.out.println("Diccionario:");
        for (int i = 0; i < palabras.size(); i++) {
            System.out.println("- " + palabras.get(i));
        }
    }
}