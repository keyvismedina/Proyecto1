/*
 * Clase que se encarga de buscar palabras en un tablero de sopa de letras.
 * Usa algoritmos como DFS y BFS para encontrar las palabras en el tablero.
 */
package com.mycompany.sopadeletraskeyvis.model;

import com.mycompany.sopadeletraskeyvis.datastructures.ListaPalabras;
import com.mycompany.sopadeletraskeyvis.datastructures.Piladfs; // Para el algoritmo DFS
import com.mycompany.sopadeletraskeyvis.datastructures.ColaBusq; // Para el algoritmo BFS
import com.mycompany.sopadeletraskeyvis.datastructures.GrafoSopaLetras;

public class BuscadorSopaLetras {

    private Tablero tablero;
    private Diccionario diccionario;

    /**
     * Crea un buscador para la sopa de letras.
     * @param tablero El tablero donde se buscarán las palabras.
     * @param diccionario Las palabras válidas que se pueden encontrar.
     */
    public BuscadorSopaLetras(Tablero tablero, Diccionario diccionario) {
        if (tablero == null) {
            throw new IllegalArgumentException("El tablero no puede ser nulo.");
        }
        if (diccionario == null) {
            throw new IllegalArgumentException("El diccionario no puede ser nulo.");
        }
        this.tablero = tablero;
        this.diccionario = diccionario;
    }

    /**
     * Busca el primer nodo que tenga la letra especificada.
     * @param letra La letra que se quiere encontrar.
     * @return El nodo con la letra, o null si no se encuentra.
     */
    public Nodo encontrarPrimerNodo(char letra) {
        for (int fila = 0; fila < tablero.getFilas(); fila++) {
            for (int col = 0; col < tablero.getColumnas(); col++) {
                if (tablero.getLetra(fila, col) == letra) {
                    return new Nodo(fila, col, tablero.getLetra(fila, col));
                }
            }
        }
        return null;
    }

    /**
     * Busca todas las palabras del diccionario en el tablero usando DFS.
     * @return Una lista con las palabras encontradas y sus rutas.
     */
    public ListaPalabras buscarTodasLasPalabrasDFS() {
        ListaPalabras palabrasEncontradas = new ListaPalabras();
        GrafoSopaLetras grafo = tablero.getGrafoAdyacencia();
        String[] palabrasDiccionario = diccionario.getTodasLasPalabras();

        for (int fila = 0; fila < tablero.getFilas(); fila++) {
            for (int col = 0; col < tablero.getColumnas(); col++) {
                int startIndex = tablero.toGraphIndex(fila, col);
                ListaPalabras currentPath = new ListaPalabras();
                boolean[] visitedArray = new boolean[grafo.getNumVertices()];

                dfsRecursivo(startIndex, String.valueOf(tablero.getLetra(fila, col)), currentPath, visitedArray, palabrasEncontradas, grafo, palabrasDiccionario);
            }
        }
        return palabrasEncontradas;
    }

    /**
     * Método auxiliar para DFS recursivo.
     * @param currentVertex El nodo actual en el grafo.
     * @param currentWord La palabra formada hasta ahora.
     * @param currentPath La ruta actual de nodos visitados.
     * @param visitedArray Array para marcar nodos visitados.
     * @param foundWords Lista donde se guardan las palabras encontradas.
     * @param grafo El grafo del tablero.
     * @param diccionarioWords Las palabras del diccionario.
     */
    private void dfsRecursivo(int currentVertex, String currentWord, ListaPalabras currentPath, boolean[] visitedArray,
                             ListaPalabras foundWords, GrafoSopaLetras grafo, String[] diccionarioWords) {
        
        visitedArray[currentVertex] = true;
        currentPath.add(currentVertex);

        int[][] pathCoords = new int[currentPath.size()][2];
        for (int i = 0; i < currentPath.size(); i++) {
            int vertexIndex = (int) currentPath.get(i);
            pathCoords[i] = tablero.toBoardCoordinates(vertexIndex);
        }

        if (currentWord.length() >= 3 && diccionario.existePalabra(currentWord)) {
            boolean alreadyFound = false;
            for (int i = 0; i < foundWords.size(); i++) {
                PalabraEncontrada pe = (PalabraEncontrada) foundWords.get(i);
                if (pe.getPalabra().equals(currentWord)) {
                    alreadyFound = true;
                    break;
                }
            }
            if (!alreadyFound) {
                foundWords.add(new PalabraEncontrada(currentWord, pathCoords));
            }
        }

        ListaPalabras neighbors = grafo.getNeighbors(currentVertex);
        for (int i = 0; i < neighbors.size(); i++) {
            int neighborVertex = (int) neighbors.get(i);
            if (!visitedArray[neighborVertex]) {
                int[] coords = tablero.toBoardCoordinates(neighborVertex);
                char nextChar = tablero.getLetra(coords[0], coords[1]);
                dfsRecursivo(neighborVertex, currentWord + nextChar, currentPath, visitedArray, foundWords, grafo, diccionarioWords);
            }
        }

        currentPath.remove(currentPath.size() - 1);
        visitedArray[currentVertex] = false;
    }

    /**
     * Busca todas las palabras del diccionario en el tablero usando BFS.
     * @return Una lista con las palabras encontradas y sus rutas.
     */
    public ListaPalabras buscarTodasLasPalabrasBFS() {
        ListaPalabras palabrasEncontradas = new ListaPalabras();
        GrafoSopaLetras grafo = tablero.getGrafoAdyacencia();

        for (int fila = 0; fila < tablero.getFilas(); fila++) {
            for (int col = 0; col < tablero.getColumnas(); col++) {
                int startVertex = tablero.toGraphIndex(fila, col);
                ColaBusq queue = new ColaBusq();
                ListaPalabras initialPath = new ListaPalabras();
                initialPath.add(startVertex);
                queue.enqueue(new Object[]{startVertex, String.valueOf(tablero.getLetra(fila, col)), initialPath});

                while (!queue.isEmpty()) {
                    Object[] currentState = (Object[]) queue.dequeue();
                    int currentV = (int) currentState[0];
                    String currentW = (String) currentState[1];
                    ListaPalabras pathV = (ListaPalabras) currentState[2];

                    int[][] pathCoords = new int[pathV.size()][2];
                    for (int i = 0; i < pathV.size(); i++) {
                        int vertexIndex = (int) pathV.get(i);
                        pathCoords[i] = tablero.toBoardCoordinates(vertexIndex);
                    }

                    if (currentW.length() >= 3 && diccionario.existePalabra(currentW)) {
                        boolean alreadyFound = false;
                        for (int i = 0; i < palabrasEncontradas.size(); i++) {
                            PalabraEncontrada pe = (PalabraEncontrada) palabrasEncontradas.get(i);
                            if (pe.getPalabra().equals(currentW)) {
                                alreadyFound = true;
                                break;
                            }
                        }
                        if (!alreadyFound) {
                            palabrasEncontradas.add(new PalabraEncontrada(currentW, pathCoords));
                        }
                    }

                    ListaPalabras neighbors = grafo.getNeighbors(currentV);
                    for (int i = 0; i < neighbors.size(); i++) {
                        int neighborV = (int) neighbors.get(i);
                        boolean isInCurrentPath = false;
                        for (int k = 0; k < pathV.size(); k++) {
                            if ((int) pathV.get(k) == neighborV) {
                                isInCurrentPath = true;
                                break;
                            }
                        }

                        if (!isInCurrentPath) {
                            ListaPalabras newPath = new ListaPalabras();
                            for (int k = 0; k < pathV.size(); k++) {
                                newPath.add(pathV.get(k));
                            }
                            newPath.add(neighborV);

                            int[] neighborCoords = tablero.toBoardCoordinates(neighborV);
                            char nextChar = tablero.getLetra(neighborCoords[0], neighborCoords[1]);
                            String newWord = currentW + nextChar;

                            queue.enqueue(new Object[]{neighborV, newWord, newPath});
                        }
                    }
                }
            }
        }
        return palabrasEncontradas;
    }

    /**
     * Busca una palabra específica en el tablero usando DFS.
     * @param targetWord La palabra a buscar.
     * @return La palabra encontrada con su ruta, o null si no se encuentra.
     */
    public PalabraEncontrada buscarPalabraDFS(String targetWord) {
        if (targetWord == null || targetWord.length() < 3) {
            return null;
        }
        String searchWord = targetWord.trim().toUpperCase();
        GrafoSopaLetras grafo = tablero.getGrafoAdyacencia();

        for (int fila = 0; fila < tablero.getFilas(); fila++) {
            for (int col = 0; col < tablero.getColumnas(); col++) {
                int startIndex = tablero.toGraphIndex(fila, col);
                if (tablero.getLetra(fila, col) != searchWord.charAt(0)) {
                    continue;
                }

                ListaPalabras currentPath = new ListaPalabras();
                boolean[] visitedArray = new boolean[grafo.getNumVertices()];
                PalabraEncontrada result = dfsBuscarPalabraRecursivo(startIndex, String.valueOf(tablero.getLetra(fila, col)), 
                                                        currentPath, visitedArray, searchWord, grafo);
                if (result != null) {
                    return result;
                }
            }
        }
        return null;
    }

    /**
     * Método auxiliar para buscar una palabra específica con DFS.
     * @param currentVertex El nodo actual en el grafo.
     * @param currentWord La palabra formada hasta ahora.
     * @param currentPath La ruta actual de nodos visitados.
     * @param visitedArray Array para marcar nodos visitados.
     * @param targetWord La palabra que se está buscando.
     * @param grafo El grafo del tablero.
     * @return La palabra encontrada con su ruta, o null si no se encuentra.
     */
    private PalabraEncontrada dfsBuscarPalabraRecursivo(int currentVertex, String currentWord, ListaPalabras currentPath, 
                                                       boolean[] visitedArray, String targetWord, GrafoSopaLetras grafo) {
        
        visitedArray[currentVertex] = true;
        currentPath.add(currentVertex);

        if (currentWord.equals(targetWord)) {
            int[][] pathCoords = new int[currentPath.size()][2];
            for (int i = 0; i < currentPath.size(); i++) {
                int vertexIndex = (int) currentPath.get(i);
                pathCoords[i] = tablero.toBoardCoordinates(vertexIndex);
            }
            return new PalabraEncontrada(currentWord, pathCoords);
        }

        if (currentWord.length() >= targetWord.length() || !targetWord.startsWith(currentWord)) {
            currentPath.remove(currentPath.size() - 1);
            visitedArray[currentVertex] = false;
            return null;
        }

        ListaPalabras neighbors = grafo.getNeighbors(currentVertex);
        for (int i = 0; i < neighbors.size(); i++) {
            int neighborVertex = (int) neighbors.get(i);
            if (!visitedArray[neighborVertex]) {
                int[] coords = tablero.toBoardCoordinates(neighborVertex);
                char nextChar = tablero.getLetra(coords[0], coords[1]);
                PalabraEncontrada result = dfsBuscarPalabraRecursivo(neighborVertex, currentWord + nextChar, 
                                                                    currentPath, visitedArray, targetWord, grafo);
                if (result != null) {
                    return result;
                }
            }
        }

        currentPath.remove(currentPath.size() - 1);
        visitedArray[currentVertex] = false;
        return null;
    }

    /**
     * Busca una palabra específica en el tablero usando BFS.
     * @param targetWord La palabra a buscar.
     * @return La palabra encontrada con su ruta, o null si no se encuentra.
     */
    public PalabraEncontrada buscarPalabraBFS(String targetWord) {
        if (targetWord == null || targetWord.length() < 3) {
            return null;
        }
        String searchWord = targetWord.trim().toUpperCase();
        GrafoSopaLetras grafo = tablero.getGrafoAdyacencia();

        for (int fila = 0; fila < tablero.getFilas(); fila++) {
            for (int col = 0; col < tablero.getColumnas(); col++) {
                int startVertex = tablero.toGraphIndex(fila, col);
                if (tablero.getLetra(fila, col) != searchWord.charAt(0)) {
                    continue;
                }

                ColaBusq queue = new ColaBusq();
                ListaPalabras initialPath = new ListaPalabras();
                initialPath.add(startVertex);
                queue.enqueue(new Object[]{startVertex, String.valueOf(tablero.getLetra(fila, col)), initialPath});

                while (!queue.isEmpty()) {
                    Object[] currentState = (Object[]) queue.dequeue();
                    int currentV = (int) currentState[0];
                    String currentW = (String) currentState[1];
                    ListaPalabras pathV = (ListaPalabras) currentState[2];

                    if (currentW.length() > targetWord.length() || !targetWord.startsWith(currentW)) {
                        continue;
                    }

                    if (currentW.equals(targetWord)) {
                        int[][] pathCoords = new int[pathV.size()][2];
                        for (int i = 0; i < pathV.size(); i++) {
                            int vertexIndex = (int) pathV.get(i);
                            pathCoords[i] = tablero.toBoardCoordinates(vertexIndex);
                        }
                        return new PalabraEncontrada(currentW, pathCoords);
                    }

                    ListaPalabras neighbors = grafo.getNeighbors(currentV);
                    for (int i = 0; i < neighbors.size(); i++) {
                        int neighborV = (int) neighbors.get(i);
                        boolean isInCurrentPath = false;
                        for (int k = 0; k < pathV.size(); k++) {
                            if ((int) pathV.get(k) == neighborV) {
                                isInCurrentPath = true;
                                break;
                            }
                        }

                        if (!isInCurrentPath) {
                            ListaPalabras newPath = new ListaPalabras();
                            for (int k = 0; k < pathV.size(); k++) {
                                newPath.add(pathV.get(k));
                            }
                            newPath.add(neighborV);

                            int[] neighborCoords = tablero.toBoardCoordinates(neighborV);
                            char nextChar = tablero.getLetra(neighborCoords[0], neighborCoords[1]);
                            String newWord = currentW + nextChar;

                            queue.enqueue(new Object[]{neighborV, newWord, newPath});
                        }
                    }
                }
            }
        }
        return null;
    }
}