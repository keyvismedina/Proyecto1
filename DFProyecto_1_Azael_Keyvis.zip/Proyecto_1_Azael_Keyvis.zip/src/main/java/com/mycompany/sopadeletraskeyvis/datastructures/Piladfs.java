/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sopadeletraskeyvis.datastructures;

/**
 * Implementación de una pila para ser usada en el algoritmo DFS.
 * Sigue el principio LIFO (último en entrar, primero en salir).
 * Almacena temporalmente las posiciones del tablero durante la búsqueda.
 */
public class Piladfs {
    private Object[] elements;
    private int top;
    private static final int DEFAULT_CAPACITY = 10;

    /**
     * Construye una pila vacía con capacidad inicial estándar.
     * El puntero 'top' comienza en -1 indicando que no hay elementos.
     */
    public Piladfs() {
        this.elements = new Object[DEFAULT_CAPACITY];
        this.top = -1;
    }

    /**
     * Apila un nuevo elemento en la parte superior.
     * Si es necesario, expande automáticamente la capacidad.
     * @param element Elemento a ser apilado (generalmente coordenadas del tablero)
     */
    public void push(Object element) {
        if (top == elements.length - 1) {
            resize();
        }
        elements[++top] = element;
    }

    /**
     * Desapila y devuelve el elemento superior de la pila.
     * @return El elemento que estaba en la cima
     * @throws IllegalStateException Si se intenta desapilar cuando la pila está vacía
     */
    public Object pop() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        Object element = elements[top];
        elements[top--] = null; // Elimina la referencia para ayudar al GC
        return element;
    }

    /**
     * Permite ver el elemento superior sin removerlo de la pila.
     * @return El elemento en la cima de la pila
     * @throws IllegalStateException Si la pila está vacía
     */
    public Object peek() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        return elements[top];
    }

    /**
     * Indica cuántos elementos hay actualmente en la pila.
     * @return Cantidad total de elementos apilados
     */
    public int size() {
        return top + 1;
    }

    /**
     * Determina si la pila no contiene elementos.
     * @return true si está vacía, false si tiene elementos
     */
    public boolean isEmpty() {
        return top == -1;
    }

    /**
     * Método interno para duplicar la capacidad de almacenamiento.
     * Se ejecuta automáticamente cuando se llena la pila.
     */
    private void resize() {
        int newCapacity = elements.length * 2;
        Object[] newElements = new Object[newCapacity];
        for (int i = 0; i <= top; i++) {
            newElements[i] = elements[i];
        }
        this.elements = newElements;
    }
}