/*
 * Clase que representa un nodo en el tablero de la sopa de letras.
 * Guarda la posición (fila, columna) y la letra del nodo.
 */
package com.mycompany.sopadeletraskeyvis.model;

class Nodo {
    Nodo(int fila, int col, char letra) {
    }
}
