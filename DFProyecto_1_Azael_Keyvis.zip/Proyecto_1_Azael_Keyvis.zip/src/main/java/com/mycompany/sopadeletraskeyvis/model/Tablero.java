/*
 * Clase que representa el tablero de la sopa de letras.
 * Maneja las letras y las conexiones entre ellas.
 */
package com.mycompany.sopadeletraskeyvis.model;

import com.mycompany.sopadeletraskeyvis.datastructures.GrafoSopaLetras;

public class Tablero {
    private char[][] letras;
    private GrafoSopaLetras grafoAdyacencia;
    private int filas;
    private int columnas;

    /**
     * Crea un tablero con las letras proporcionadas.
     * @param letras Matriz de caracteres que representa el tablero.
     */
    public Tablero(char[][] letras) {
        if (letras == null || letras.length == 0 || letras[0].length == 0) {
            throw new IllegalArgumentException("El tablero no puede estar vacío.");
        }
        this.filas = letras.length;
        this.columnas = letras[0].length;
        this.letras = new char[this.filas][this.columnas];

        for (int i = 0; i < this.filas; i++) {
            for (int j = 0; j < this.columnas; j++) {
                this.letras[i][j] = letras[i][j];
            }
        }
        
        this.grafoAdyacencia = new GrafoSopaLetras(this.filas * this.columnas);
        conectarAdyacencias();
    }

    /**
     * Conecta las celdas adyacentes en el grafo.
     * Las conexiones incluyen horizontales, verticales y diagonales.
     */
    private void conectarAdyacencias() {
        int[] dr = {-1, -1, -1, 0, 0, 1, 1, 1}; // Movimientos en fila.
        int[] dc = {-1, 0, 1, -1, 1, -1, 0, 1}; // Movimientos en columna.

        for (int r = 0; r < filas; r++) {
            for (int c = 0; c < columnas; c++) {
                int verticeActual = toGraphIndex(r, c);

                for (int i = 0; i < 8; i++) {
                    int nr = r + dr[i];
                    int nc = c + dc[i];

                    if (nr >= 0 && nr < filas && nc >= 0 && nc < columnas) {
                        int verticeAdyacente = toGraphIndex(nr, nc);
                        grafoAdyacencia.addEdge(verticeActual, verticeAdyacente);
                    }
                }
            }
        }
    }

    /**
     * Convierte coordenadas (fila, columna) a un índice del grafo.
     * @param fila La fila en el tablero.
     * @param columna La columna en el tablero.
     * @return El índice correspondiente en el grafo.
     */
    public int toGraphIndex(int fila, int columna) {
        return fila * columnas + columna;
    }

    /**
     * Convierte un índice del grafo a coordenadas (fila, columna).
     * @param index El índice en el grafo.
     * @return Las coordenadas como {fila, columna}.
     */
    public int[] toBoardCoordinates(int index) {
        int fila = index / columnas;
        int columna = index % columnas;
        return new int[]{fila, columna};
    }

    /**
     * Obtiene la letra en una posición específica del tablero.
     * @param fila La fila de la letra.
     * @param columna La columna de la letra.
     * @return La letra en esa posición.
     * @throws IndexOutOfBoundsException Si las coordenadas no son válidas.
     */
    public char getLetra(int fila, int columna) {
        if (fila < 0 || fila >= filas || columna < 0 || columna >= columnas) {
            throw new IndexOutOfBoundsException("Coordenadas fuera de rango: (" + fila + ", " + columna + ")");
        }
        return letras[fila][columna];
    }

    /**
     * Obtiene el número de filas del tablero.
     * @return El número de filas.
     */
    public int getFilas() {
        return filas;
    }

    /**
     * Obtiene el número de columnas del tablero.
     * @return El número de columnas.
     */
    public int getColumnas() {
        return columnas;
    }

    /**
     * Devuelve el grafo de adyacencia del tablero.
     * @return El grafo con las conexiones entre celdas.
     */
    public GrafoSopaLetras getGrafoAdyacencia() {
        return grafoAdyacencia;
    }

    /**
     * Imprime el tablero en la consola (útil para depuración).
     */
    public void imprimirTablero() {
        System.out.println("Tablero:");
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                System.out.print(letras[i][j] + " ");
            }
            System.out.println();
        }
    }
}