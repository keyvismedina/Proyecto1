/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/*
 * Clase simple para medir tiempos. Útil para saber cuánto tarda
 * en ejecutarse alguna parte del código.
 */
package com.mycompany.sopadeletraskeyvis.utils;

public class Timer {

    private long startTime;
    private long endTime;

    /**
     * Empieza a contar el tiempo. Guarda el momento actual.
     */
    public void start() {
        this.startTime = System.nanoTime();
        this.endTime = 0;
    }

    /**
     * Detiene el contador. Guarda el momento actual.
     */
    public void stop() {
        this.endTime = System.nanoTime();
    }

    /**
     * Devuelve el tiempo que pasó entre start() y stop() en milisegundos.
     * Si no se usó bien el timer, devuelve 0.
     */
    public long getElapsedTimeMillis() {
        if (startTime == 0 || endTime == 0) {
            return 0;
        }
        return (endTime - startTime) / 1_000_000;
    }
    
    /**
     * Igual que getElapsedTimeMillis() pero devuelve nanosegundos.
     */
    public long getElapsedTimeNanos() {
        if (startTime == 0 || endTime == 0) {
            return 0;
        }
        return (endTime - startTime);
    }
    
    /**
     * Reinicia el timer para poder usarlo de nuevo.
     */
    public void reset() {
        this.startTime = 0;
        this.endTime = 0;
    }
}